function Condition(arg) {
	this.name=arg.name;
	if (!this.name)
		this.name="Condition missing name";
	this.type=arg.type;
	this.match=function(card) {
		if (card)
			return arg.match(card);
		else
			return false;
	}
	if (!this.match)
		this.match=function(){return true}

	this.toString=function(){return this.name;};
}

function Requirement(cond, qty) {
	if (cond) {
		this.match=cond.match;
		this.name=cond.name;
		this.type=cond.type;
		this.qty=1;
		if (qty)
			this.qty=qty;
		this.toString=function(){return this.name;};
	}
}


function Card(arg) {
	this.name=arg.name;
	if (!this.name)
		this.name="Missing name";
	this.set=arg.set;
	if (!this.set)
		this.set="";
	this.types=arg.types;
	if (!this.types)
		this.types="";
	this.light=arg.light;
	if (!this.light)
		this.light=false;
	this.strength=arg.strength;
	if (!this.strength)
		this.strength=false;
	this.attack=arg.attack;
	if (!this.attack)
		this.attack=false;
	this.magicAttack=arg.magicAttack;
	if (!this.magicAttack)
		this.magicAttack=false;
	this.removesMonstersFromHall=arg.removesMonstersFromHall;
	if (!this.removesMonstersFromHall)
		this.removesMonstersFromHall=false;
	this.destroysDisease=arg.destroysDisease;
	if (!this.destroysDisease)
		this.destroysDisease=false;
	this.requirements=arg.requirements;
	if (!this.requirements)
		this.requirements=[];
	this.is=function(what){
		if (this.types)
			return (this.types.indexOf(what)!=-1)
		else
			return false;
	}
	this.has=function(what){
		if (this[what])
			return this[what];
		else
			return false;
	}
	this.toString=function(){return this.name;};
}

function GameSet() {
	this.dungeonDeck=new Array();
	this.extraDungeonCards=0;
	this.useSpecialDiseases=false;
	for (var key in monsters)
		if (cardRequired(monsters[key]))
			this.dungeonDeck[this.dungeonDeck.length]=monsters[key];
	for (var key in traps)
		if (cardRequired(traps[key])) {
			this.dungeonDeck[this.dungeonDeck.length]=traps[key];
			this.extraDungeonCards++;
		}
	for (var key in guardians)
		if (cardRequired(guardians[key])) {
			this.dungeonDeck[this.dungeonDeck.length]=guardians[key];
			this.extraDungeonCards++;
		}
	this.heroes=new Array();
	for (var key in heroes)
		if (cardRequired(heroes[key]))
			this.heroes[this.heroes.length]=heroes[key];
	this.village=new Array();
	for (var key in village)
		if (cardRequired(village[key]))
			this.village[this.village.length]=village[key];
	this.dungeonDeckSize=function() {
		log("Dungeon deck size: "+(this.extraDungeonCards*1+numberOfMonsters*1));
		return this.extraDungeonCards*1+numberOfMonsters*1;
	}
	this.toString=function(){
		return "Dungeon:"+this.dungeonDeck+"\r\nHeroes:"+this.heroes+"\r\nVillage:"+this.village+"\r\n\r\n";
	}
}

function cardRequired(which) {
	var id=getId(which);
	return $("#"+id).val()=="Yes"
}

function GameRequirements() {
	this.reqs=new Array();
	this.add=function(req) {
		if (document.getElementById("useConditions").checked) {
			var matched=false;
			for (var i=0; i<this.reqs.length; i++) {
				if (this.reqs[i].name==req.name) {
					matched=true;
					this.reqs[i].qty=Math.max(this.reqs[i].qty, req.qty);
				}
			}
			if (!matched)
				this.reqs[this.reqs.length]=clone(req);
		}
	}
	this.count=function() {
		var x=0;
		for (var i=0; i<this.reqs.length; i++)
			x+=this.reqs[i].qty;
		return x;
	}
	this.match=function(card) {
		var toReturn=false;
		for (var i=0; i<this.reqs.length; i++)
			if (this.reqs[i].qty>0 && this.reqs[i].match(card)) {
				toReturn=true;
				this.reqs[i].qty--;
				log(card+" matched "+this.reqs[i]+"; "+this.count()+" matches remaining");
			}
		return toReturn;
	}
}

//Used to determine whether a hero is 'strong.' Based on level 1 hero.
var heroStrengthThreshold=5;

var diseaseChance=.5;
var soloGame=false;

//		cardType(name, 				min,max,minDef,maxDef, side)
var cardTypes = [
	new CardType("Setting",			0,	7,	0,	1, "Dungeon"),
	new	CardType("Thunderstone",	1,	5,	1,	1, "Dungeon"),
	new	CardType("Monster",			1,	6,	3,	3, "Dungeon"),
	new	CardType("Guardian",		0,	5,	0,	1, "Dungeon"),
	new	CardType("Trap",			0,	3,	0,	1, "Dungeon"),
	new	CardType("Treasure",		0,	3,	0,	1, "Dungeon"),
	new	CardType("Hero",			2,	8,	4,	4, "Village"),
	new	CardType("Village",			4,	12,	8,	8, "Village")
];

var cards=new Array();
for (var i=0; i<cardTypes.length; i++)
	cards[cardTypes[i].name]=new Array();

function getOptions() {
	diseaseChance=document.getElementById("diseaseSelect").value;
	soloGame=document.getElementById("soloGame").checked;
	for (var i=0; i<cardTypes.length; i++) {
		var type = cardTypes[i];
		var min = document.getElementById("min_"+type.name).value;
		var max = document.getElementById("max_"+type.name).value;
		if (min == max)
			type.count = min;
		else {
			if (min > max) {
				min ^= max; max ^= min; min ^= max; //XOR swap values
			}
			var range = max - min + 1; //Increase range by 1. E.g. 2-4 should have range 3, because you want 2 + (0, 1 or 2)
			var rand = Math.floor(Math.random()*range);
			type.count = rand*1 + min*1;
		}
	}
}

//Sets
var set={
	base: "Base",
	doom: "Doomgate Legion",
	dragonspire: "Dragonspire",
	promo: "Promo",
	wrath: "Wrath Of The Elements"
}

//Logging stuff
var indent=0;
function log(s) {
	//return false;
	if (document.getElementById("showLog").checked) {
		for (logi=0; logi<indent; logi++)
			document.getElementById("log").value+="\t";
		document.getElementById("log").value+=s+"\n";
	}
}

//Fisher-Yates shuffle
//Via http://sedition.com/perl/javascript-fy.html
function fisherYates ( myArray ) {
  var i = myArray.length;
  if ( i == 0 ) return false;
  while ( --i ) {
     var j = Math.floor( Math.random() * ( i + 1 ) );
     var tempi = myArray[i];
     var tempj = myArray[j];
     myArray[i] = tempj;
     myArray[j] = tempi;
   }
}

//Clone object
//Via http://keithdevens.com/weblog/archive/2007/Jun/07/javascript.clone
function clone(obj){
    if(obj == null || typeof(obj) != 'object')
        return obj;

    var temp = new obj.constructor(); // changed (twice)
    for(var key in obj)
        temp[key] = clone(obj[key]);

    return temp;
}

//Start cookie stuff
var cookieName="tsrandOptions";
var enableSaving=false;
function restoreOptions() {
	log("Restoring cookie")
	indent++;
	cookie=$.cookie(cookieName);
	log("Cookie loaded: "+cookie);
	if (cookie) {
		opt=JSON.parse(cookie);
		for (var id in opt) {
			log("Loaded: "+id+" = "+opt[id]);
			if (document.getElementById(id)) {
				element=document.getElementById(id);
				if (opt[id].indexOf("chk")==0)
					element.checked=(opt[id]=="chk:true");
				else
					element.value=opt[id];
			}
		}
	}
	indent--;
	for (var i in set)
		setClicked(getId(set[i]));
	for (var i=0; i<cardTypes.length; i++) {
		var type = cardTypes[i];
		var deck = cards[type.name];
		for (var j=0; j<deck.length; j++) {
			styleCard(getId(deck[j]));
		}
	}
	toggleLog();
	enableSaving=true;
}
function saveOptions() {
	setTimeout(_saveOptions,10); //Small delay to make sure checkboxes have changed
}
function _saveOptions() {
	document.getElementById("log").value="";
	if (!enableSaving)
		return false;
	log("Saving cookie")
	var opt={}
	function save(id, def) {
		var formElement=document.getElementById(id);
		if (formElement) {
			if (formElement.type=="checkbox") {
				if (formElement.checked != def) {
					console.log(formElement.id+": "+formElement.checked+" | "+def+" | "+(formElement.checked != def));
					opt[id]="chk:"+formElement.checked;
				}
			}
			else if (formElement.value != def) {
				console.log(formElement.id+": "+formElement.value+" | "+def+" | "+(formElement.value != def));
				opt[id]=formElement.value;
			}
		}
	}
	save("diseaseSelect", .5);
	save("soloGame", false);
	save("showLog", false);
	for (var key in set) {
		var s = set[key];
		var id = getId(s);
		save(id, true);
	}
	for (var i in cardTypes) {
		var type = cardTypes[i];
		save(type.minId, type.minDef);
		save(type.maxId, type.maxDef);
		for (var j in cards[type.name]) {
			var id=getId(cards[type.name][j]);
			save(id, "Maybe");
		}
	}

	indent++;
	for (i in opt)
		log(i+": "+opt[i]);
	indent--;
	cookie=JSON.stringify(opt)
	log("Cookie: "+cookie);
	$.cookie(cookieName, cookie, { expires: 365 });
}
//End cookie stuff

function validate(card) {
	var foo = getId(card.set);
	var toReturn = ((document.getElementById(getId(card)).value=="Maybe")
		&& (document.getElementById(getId(card.set)).checked));
	toReturn=toReturn&&(!soloGame || isAppropriateForSinglePlayer(card));
	return toReturn;
}

var decks=new Array();

function buildDeck(type) {
	var toReturn=new Array();
	var source = cards[type.name];
	for (var i=0; i<source.length; i++)
		if (validate(source[i]))
			toReturn[toReturn.length]=i;
	fisherYates(toReturn);
	return toReturn;
}
function buildDecks() {
	for (var i=0; i<cardTypes.length; i++) {
		var type=cardTypes[i];
		decks[type.name]=buildDeck(type);
	}
}

var listSets=new Array();
function printList(type) {
	listSets[type.name]=new Array();
	var toReturn="<li class='listHeader' id='listHeader"+type.name+"'>"+type.name+" <span class='typeOptions'>";
	toReturn += getNumericBoxes(type);
	toReturn += "</span></li>";
	for (var i=0; i<cards[type.name].length; i++) {
		var card = cards[type.name][i];
		var set = card.set;
		var c = getClass(card);
		var id = getId(card);
		listSets[type.name][set]=true;
		toReturn += "<li class='"+c+" noSelect'><select id='"+id+"' onchange='javascript:saveOptions()' checked='checked'><option value='No'>No</option><option value='Maybe' selected='selected'>Maybe</option><option value='Yes'>Yes</option></select><label for='"+id+"' class='YesNoMaybe'>"+card+"</label></li>";
	}
	return toReturn;
}

function getNumericBoxes(type) {
	var minAdjustCall='javascript:adjust("min", "'+type.minId+'", "'+type.maxId+'");'
	var maxAdjustCall='javascript:adjust("max", "'+type.minId+'", "'+type.maxId+'");'
	var minHTML="<select id='"+type.minId+"' onchange='javascript:adjust(\"min\", \""+type.minId+"\", \""+type.maxId+"\");'>";
	var maxHTML="<select id='"+type.maxId+"' onchange='javascript:adjust(\"max\", \""+type.minId+"\", \""+type.maxId+"\");'>";
	for (var i=type.min; i<=type.max; i++) {
		var minSelected = "";
		var maxSelected = "";
		if (i == type.minDef)
			minSelected = 'selected="selected"';
		if (i == type.maxDef)
			maxSelected = 'selected="selected"';
		minHTML+="<option value='"+i+"' "+minSelected+">"+i+"</option>"
		maxHTML+="<option value='"+i+"' "+maxSelected+">"+i+"</option>"
	}
	minHTML+='</select></span>';
	maxHTML+='</select></span>';
	return minHTML+' - '+maxHTML;
}

function adjust(how, minId, maxId) {
	var min = document.getElementById(minId);
	var max = document.getElementById(maxId);
	if (min.value > max.value) {
		if (how == "min")
			max.value=min.value;
		else
			min.value=max.value;
	}
	saveOptions();
}

function printSetList() {
	var toReturn="<li class='listHeader' id='listHeaderSet'>Set</li>";
	for (var key in set) {
		var s = set[key];
		var c = getClass(s);
		var id = getId(s);
		toReturn += "<li class='"+c+" noSelect'><input type='checkbox' id='"+id+"' onclick='"+getClickEvent(s)+"' checked='checked'><label for='"+id+"'>"+s+"</label></li>";
	}
	return toReturn;
}

function getClickEvent(input) {
	if (input.name)
		return 'javascript:cardClicked("'+getId(input)+'")';
	else
		return 'javascript:setClicked("'+getId(input)+'")';
}

function getId(input) {
	name=input;
	prefix="set";
	if (input.name) {
		name=input.name;
		prefix="card";
	}
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	stripped=name.replace(invalidChars,'');
	return prefix+stripped.charAt(0).toUpperCase()+stripped.substring(1);
}

function getClass(input, noPrefix) {
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	prefix="";
	if (input.name) {
		stripped=input.set.replace(invalidChars,'');
		if (!noPrefix)
			prefix="card ";
		return prefix+stripped;
	} else {
		stripped=input.replace(invalidChars,'');
		if (!noPrefix)
			prefix="set ";
		return prefix+stripped;
	}
}

function getYesNoMaybeBox(id) {
	var toReturn='<span class="option"><select id="'+id+'" onchange="javascript:saveOptions()">'
		+'<option value="0">No</option>'
		+'<option value=".5">Maybe</option>'
		+'<option value="1" selected="selected">Yes</option></select>'
		+'</span>';
	return toReturn;
}

function styleCard(which) {
	var select=$("#"+which);
	var label=$("label[for='"+which+"']");
	var val=select.val();
	select.parent().removeClass("disabled");
	label.removeClass("required");
	if (val=="No")
		select.parent().addClass("disabled");
	else if (val=="Yes")
		label.addClass("required");
}

function setClicked(which) {
	setClass="."+which.substring(3); //Strip the "set" prefix
	if (document.getElementById(which).checked) {
		$(".card"+setClass).removeClass("hidden");
		$("#"+which).parent().removeClass("disabled");
	} else {
		$(".card"+setClass).addClass("hidden");
		$("#"+which).parent().addClass("disabled");
	}
	setListVisibilities();
	saveOptions();
}

function setListVisibilities() {
	for (var list in listSets) {
		var setId=getId(list);
		var listId="listHeader"+list;
		if (document.getElementById(listId)) {
			var show=false;
			for (var set in listSets[list]) {
				var setId=getId(set);
				show |= document.getElementById(setId).checked
			}
			if (show)
				$("#"+listId).removeClass("hidden");
			else
				$("#"+listId).addClass("hidden");
		}
	}
}

function isAppropriateForSinglePlayer(card) {
	return !card.removesMonstersFromHall;
}

function randomize() {
	var gameSet=getGameSet();

	for (var i=0; i<cardTypes.length; i++) {
		var type = cardTypes[i];
		var deck = gameSet.decks[type.name];
		var listId = "#"+type.name+"List"
		var list = document.getElementById(type.name+"List");
		if (gameSet.useSpecialDiseases)
			$("#useSpecialDiseases").removeClass("hidden");
		else
			$("#useSpecialDiseases").addClass("hidden");
		if (deck.length>0) {
			$(listId).removeClass("hidden");
			list.innerHTML="<li class='listHeader'>"+type.name+"</li>";
			for (var j=0; j<deck.length; j++) {
				var card = deck[j];
				list.innerHTML+="<li class='gameCard "+getClass(card.set, true)+"'>"+card.name+"</li>";
			}
		} else
			$(listId).addClass("hidden");
	}
}

function getGameSet() {
	document.getElementById("log").value="";
	getOptions();
	gameSet=new GameSet();
	buildDecks();
	var gameRequirements=new Array();
	for (var i=0; i<cardTypes.length; i++)
		gameRequirements[cardTypes[i].name]=new GameRequirements()

	//Pick diseases
	//Can be overridden to true by monsters
	if (Math.random()<diseaseChance) {
		gameSet.useSpecialDiseases=true;
	} else log("Not using special disease");
	
	for (var i=0; i<cardTypes.length; i++) {
		var type=cardTypes[i];
		var deck=gameSet.decks[type.name];
		var gameReqs=gameRequirements[type.name];
		for (var j=0; deck.length<type.count && j<decks[type.name].length; j++) {
			var card = cards[type.name][decks[type.name][j]];
			var keep = (j+gameReqs.count() < type.count); //False if not enough "free" slots left
			keep = (gameReqs.match(card)||keep); //True if the card matches a requirement. Note that we evaluate match is true before checking if keep is already true!
			keep = (keep||decks[type.name].length-j <= type.count-deck.length); //True if we're running out of cards
			if (keep) {
				deck[deck.length]=card;
				for (var k=0; card.requirements && k<card.requirements.length; k++) {
					var req = card.requirements[k];
					if (req.type=="Disease")
						gameSet.useSpecialDiseases=true;
					else
						gameRequirements[req.type].add(req);
				}
			} else log(card+" discard due to lack of space");
		}
		deck.sort();
		if (gameReqs.count() > 0) {
			log(type.name+" requirements:");
			indent++;
			for (var j=0; j<gameReqs.reqs.length; j++) {
				var req = gameReqs.reqs[j];
				log(req+" required "+req.qty+" more");
			}
			indent--;
		}
	}
	return gameSet;
}

function toggleLog() {
	if (document.getElementById("showLog").checked)
		$("#log").removeClass("hidden");
	else
		$("#log").addClass("hidden");
	saveOptions();
}

//iOS label fix
//via http://www.thewatchmakerproject.com/blog/how-to-fix-the-broken-ipad-form-label-click-issue/
if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/iPad/i)) {
	$(document).ready(function () {
		$('label[for]').click(function () {
			var el = $(this).attr('for');
			if ($('#' + el + '[type=radio], #' + el + '[type=checkbox]').attr('selected', !$('#' + el).attr('selected'))) {
				return;
			} else {
				$('#' + el)[0].focus();
			}
		});
	});
}

//Enables the yes/no/maybe tri-state boxes
$(document).ready(function() {
	$(".YesNoMaybe").click(function(event) {
		event.preventDefault();
		var id = $(this).attr('for');
		var select=$("#"+id);
		var label=$("label[for='"+id+"']");
		var val=select.val();
		select.parent().removeClass("disabled");
		label.removeClass("required");
		//alert(val);
		if (val=="Yes") {
			select.val("Maybe");
		} else if (val=="No") {
			select.val("Yes");
			label.addClass("required");
		} else {
			select.val("No");
			select.parent().addClass("disabled");
		}
		saveOptions();
	})
});

//Disable text selection on elements with class noSelect
//Via http://chris-barr.com/entry/disable_text_selection_with_jquery/
$(function(){
	$.extend($.fn.disableTextSelect = function() {
		return this.each(function(){
			if($.browser.mozilla){//Firefox
				$(this).css('MozUserSelect','none');
			}else if($.browser.msie){//IE
				$(this).bind('selectstart',function(){return false;});
			}else{//Opera, etc.
				$(this).mousedown(function(){return false;});
			}
		});
	});
	$('.noSelect').disableTextSelect();//No text selection on elements with a class of 'noSelect'
});

//Set sizing
function resize() {
	width=Math.round($("body").width()*.95);
	minWidth=320; //minimum width *per column* required before it can be side-by-side
	if (width>minWidth*2)
		$(".container, #log").width("50%");
	else
		$(".container, #log").width("100%");
}
$(document).ready(function() {
	resize();
});
$(window).resize(function(){
	resize();
});

$(window).unload(function() {
  saveOptions();
});

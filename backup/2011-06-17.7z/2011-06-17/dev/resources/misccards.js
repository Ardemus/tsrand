cards["Thunderstone"][cards["Thunderstone"].length]=new Card({
	name: "Stone of Agony",
	set: set.wrath
});
cards["Thunderstone"][cards["Thunderstone"].length]=new Card({
	name: "Stone of Avarice",
	set: set.doom
});
cards["Thunderstone"][cards["Thunderstone"].length]=new Card({
	name: "Stone of Mystery",
	set: set.base
});
cards["Thunderstone"][cards["Thunderstone"].length]=new Card({
	name: "Stone of Scorn",
	set: set.dragonspire
});
cards["Thunderstone"][cards["Thunderstone"].length]=new Card({
	name: "Stone of Terror",
	set: set.dragonspire
});

cards["Trap"][cards["Trap"].length]=new Card({
	name: "Trap * Death",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief)
	]
});
cards["Trap"][cards["Trap"].length]=new Card({
	name: "Trap * Dire",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief),
		new Requirement(req_hero_cleric)
	]
});
cards["Trap"][cards["Trap"].length]=new Card({
	name: "Trap * Draconic",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_thief),
	]
});

cards["Guardian"][cards["Guardian"].length]=new Card({
	name: "Dark Champion",
	set: set.wrath,
	requirements: [
	]
});
cards["Guardian"][cards["Guardian"].length]=new Card({
	name: "Death Sentinel",
	set: set.promo,
	requirements: [
	]
});
cards["Guardian"][cards["Guardian"].length]=new Card({
	name: "Guardian of Night",
	set: set.dragonspire,
	requirements: [
	]
});
cards["Guardian"][cards["Guardian"].length]=new Card({
	name: "Guardian of Torment",
	set: set.dragonspire,
	requirements: [
	]
});
cards["Guardian"][cards["Guardian"].length]=new Card({
	name: "Unholy Guardian",
	set: set.doom,
	requirements: [
	]
});

cards["Treasure"][cards["Treasure"].length]=new Card({
	name: "Amulet Treasure",
	set: set.doom,
	requirements: [
	]
});
cards["Treasure"][cards["Treasure"].length]=new Card({
	name: "Figurine Treasure",
	set: set.dragonspire,
	requirements: [
	]
});
cards["Treasure"][cards["Treasure"].length]=new Card({
	name: "Ulbrick's Treasure",
	set: set.doom,
	requirements: [
	]
});

cards["Setting"][cards["Setting"].length]=new Card({
	name: "Barrowsdale",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Doomgate",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Dragonspire",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Dreadwatch",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Feayn Swamp",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Grimhold",
	set: set.dragonspire
});
cards["Setting"][cards["Setting"].length]=new Card({
	name: "Regian Cove",
	set: set.dragonspire
});

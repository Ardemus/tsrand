thunderstones=new Array();
thunderstones[thunderstones.length]=new Card({
	name: "Stone of Mystery",
	set: set.base
});
thunderstones[thunderstones.length]=new Card({
	name: "Stone of Agony",
	set: set.wrath
});
thunderstones[thunderstones.length]=new Card({
	name: "Stone of Avarice",
	set: set.doom
});
thunderstones[thunderstones.length]=new Card({
	name: "Stone of Scorn",
	set: set.dragonspire
});
thunderstones[thunderstones.length]=new Card({
	name: "Stone of Terror",
	set: set.dragonspire
});

traps=new Array();
traps[traps.length]=new Card({
	name: "Trap * Death",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief)
	]
});
traps[traps.length]=new Card({
	name: "Trap * Dire",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief),
		new Requirement(req_hero_cleric)
	]
});
traps[traps.length]=new Card({
	name: "Trap * Draconic",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_thief),
	]
});

guardians=new Array();
guardians[guardians.length]=new Card({
	name: "Dark Champion",
	set: set.wrath,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Death Sentinel",
	set: set.promo,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Guardian of Night",
	set: set.dragonspire,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Guardian of Torment",
	set: set.dragonspire,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Unholy Guardian",
	set: set.doom,
	requirements: [
	]
});

treasures=new Array();
treasures[treasures.length]=new Card({
	name: "Amulet Treasures",
	set: set.doom,
	requirements: [
	]
});
treasures[treasures.length]=new Card({
	name: "Figurine Treasures",
	set: set.dragonspire,
	requirements: [
	]
});
treasures[treasures.length]=new Card({
	name: "Ulbrick's Treasures",
	set: set.doom,
	requirements: [
	]
});

settings=new Array();
settings[settings.length]=new Card({
	name: "Barrowsdale",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Doomgate",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Dragonspire",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Dreadwatch",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Feayn Swamp",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Grimhold",
	set: set.dragonspire
});
settings[settings.length]=new Card({
	name: "Regian Cove",
	set: set.dragonspire
});

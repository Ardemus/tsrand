monsters=new Array();
monsters[monsters.length]=new Card({
	name: "Abyssal",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_wizard), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Abyssal * Thunderspawn",
	set: set.doom,
	requirements: [
		new Requirement(req_hero_archer), 
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_wizard)
	]
});
monsters[monsters.length]=new Card({
	name: "Bandit * Humanoid",
	set: set.dragonspire,
	requirements: [
	]
});
monsters[monsters.length]=new Card({
	name: "Cultist * Humanoid",
	set: set.doom,
	requirements: [
		new Requirement(req_village_item), 
		new Requirement(req_village_weapon), 
		new Requirement(req_village_spell) 
	]
});
monsters[monsters.length]=new Card({
	name: "Dark Enchanted",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_archer),
		new Requirement(req_village_edged_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Doomknight * Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_fighter), 
		new Requirement(req_village_light), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Dragon",
	set: set.base,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Fire",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_item),
		new Requirement(req_village_spell)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Nature",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Pain",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Enchanted",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Evil Druid * Humanoid",
	set: set.doom,
	requirements: [
		new Requirement(req_hero_cleric),
		new Requirement(req_disease_special),
		new Requirement(req_hero_destroys_disease)
	]
});
monsters[monsters.length]=new Card({
	name: "Giant",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_strength),
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Golem",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength)
	]
});
monsters[monsters.length]=new Card({
	name: "Horde",
	set: set.wrath,
	requirements: [
	]
});
monsters[monsters.length]=new Card({
	name: "Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Hydra * Dragon",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Ooze",
	set: set.base,
	requirements: [
		new Requirement(req_village_edged_weapon), 
		new Requirement(req_village_food), 
		new Requirement(req_village_nonedged_weapon), 
	]
});
monsters[monsters.length]=new Card({
	name: "Orc * Humanoid",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "The Swarm",
	set: set.doom,
	requirements: [
		new Requirement(req_disease_special)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Doom",
	set: set.base,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Lich",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_attack),
		new Requirement(req_hero_cleric),
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_magic_attack),
		new Requirement(req_hero_wizard),
		new Requirement(req_village_attack),
		new Requirement(req_village_magic_attack),
		new Requirement(req_village_spell)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Plague",
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_destroys_disease)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Spirit",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Stormwraith",
	set: set.doom,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell)
	]
});

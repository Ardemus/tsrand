allCards=new Array();
var dungeonListHTML="";
var villageListHTML="";
var cardListHTML="";
for (var i=0; i<cardTypes.length; i++) {
	var type=cardTypes[i];
	if (type.side=="Dungeon")
		dungeonListHTML += '<ul id="'+type.name+'List" class="cardList"></ul>';
	else
		villageListHTML += '<ul id="'+type.name+'List" class="cardList"></ul>';
	cardListHTML += printList(type);
}
document.getElementById("dungeonTypes").innerHTML = dungeonListHTML+"<span id='useSpecialDiseases' class='hidden'><strong>Use special diseases</strong></span>";
document.getElementById("villageTypes").innerHTML = villageListHTML;
document.getElementById("filterSetList").innerHTML = printSetList();
document.getElementById("filterCardList").innerHTML = cardListHTML;

restoreOptions();
cards["Village"][cards["Village"].length]=new Card({
	name: "Ambrosia",
	set: set.wrath,
	types: "Item Food Magic",
	attack: true,
	strength: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Amulet of Power",
	set: set.wrath,
	types: "Item Light Magic",
	light: true,
	strength: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Arcane Energies",
	set: set.base,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Banish",
	set: set.base,
	types: "Spell",
	removesMonstersFromHall: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Barkeep",
	set: set.base,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Battle Fury",
	set: set.base,
	types: "Spell",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Blacksmith",
	set: set.wrath,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Blessed Hammer",
	set: set.doom,
	types: "Weapon Blunt",
	magicAttack: true,
	weight: 4
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Bluefire Staff",
	set: set.dragonspire,
	types: "Weapon Blunt Magic",
	magicAttack: true,
	weight: 0
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Border Guard",
	set: set.doom,
	types: "Villager Mercenary",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Burnt Offering",
	set: set.dragonspire,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Chieftan's Drum",
	set: set.dragonspire,
	types: "Item Magic"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Claymore",
	set: set.wrath,
	types: "Weapon Edged",
	attack: true,
	weight: 8
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Creeping Death",
	set: set.wrath,
	types: "Spell",
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Cursed Bow",
	set: set.thorn,
	types: "Weapon Bow",
	attack: true,
	weight: 4
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Cursed Mace",
	set: set.wrath,
	types: "Weapon Blunt",
	attack: true,
	weight: 5
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Cyclone",
	set: set.doom,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Divine Staff",
	set: set.doom,
	types: "Weapon Magic",
	magicAttack: true,
	weight: 2
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Doomgate Squire",
	set: set.doom,
	types: "Villager Mercenary",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Drill Sergeant",
	set: set.thorn,
	types: "Villager Mercenary"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Elite Militia",
	set: set.thorn,
	types: "Militia Hero",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Feast",
	set: set.base,
	types: "Item Food",
	attack: true,
	strength: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Fireball",
	set: set.base,
	types: "Spell",
	light: true,
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Flaming Sword",
	set: set.base,
	types: "Weapon Edged",
	light: true,
	magicAttack: true,
	weight: 5
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Flask of Oil",
	set: set.doom,
	types: "Weapon Item Light",
	attack: true,
	light: true,
	weight: 2
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Foresight Elixir",
	set: set.wrath,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Fortune Teller",
	set: set.doom,
	types: "Villager Mercenary",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Frost Bolt",
	set: set.dragonspire,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Frost Giant Axe",
	set: set.dragonspire,
	types: "Weapon Edged",
	attack: true,
	weight: 6
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Glowberries",
	set: set.doom,
	types: "Item Food Light",
	light: true,
	strength: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Goodberries",
	set: set.base,
	types: "Item Food Magic",
	magicAttack: true,
	strength: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Greed Blade",
	set: set.doom,
	types: "Weapon Edged",
	attack: true,
	weight: 6
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Guardian Blade",
	set: set.dragonspire,
	types: "Weapon Edged",
	attack: true,
	weight: 5
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Guide",
	set: set.dragonspire,
	types: "Villager Mercenary",
	light: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Guiding Light",
	set: set.thorn,
	types: "Item Light Magic",
	light: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Hatchet",
	set: set.base,
	types: "Weapon Edged",
	attack: true,
	weight: 3
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Highland Officer",
	set: set.thorn,
	types: "Villager Mercenary"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Illusory Blade",
	set: set.wrath,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Insight Blade",
	set: set.thorn,
	types: "Weapon Edged",
	attack: true,
	weight: 6
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Lantern",
	set: set.base,
	types: "Item Light",
	light: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Lightstone Gem",
	set: set.base,
	types: "Item Light Magic",
	light: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Magi Staff",
	set: set.wrath,
	types: "Weapon Blunt Magic",
	magicAttack: true,
	removesMonstersFromHall: true,
	weight: 3
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Magic Missile",
	set: set.wrath,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Magical Aura",
	set: set.base,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Pawnbroker",
	set: set.base,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Pious Champion",
	set: set.doom,
	types: "Villager Mercenary",
	destroysDisease: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Plaguesmiter",
	set: set.thorn,
	types: "Weapon Blunt",
	destroysDisease: true,
	magicAttack: true,
	weight: 5
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Polearm",
	set: set.base,
	types: "Weapon Edged",
	attack: true,
	weight: 2
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Polymorph",
	set: set.dragonspire,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Power Word: Kill",
	set: set.thorn,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Quartermaster",
	set: set.dragonspire,
	types: "Villager Mercenary",
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Recurve Bow",
	set: set.dragonspire,
	types: "Weapon Bow",
	attack: true,
	weight: 5
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Sage",
	set: set.wrath,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Scout",
	set: set.dragonspire,
	types: "Villager Mercenary"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Scroll of Chaos",
	set: set.thorn,
	types: "Item Magic"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Short Bow",
	set: set.wrath,
	types: "Weapon Bow",
	attack: true,
	weight: 4
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Short Sword",
	set: set.base,
	types: "Weapon Edged",
	attack: true,
	weight: 4
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Silverstorm",
	set: set.dragonspire,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Skullbreaker",
	set: set.dragonspire,
	types: "Weapon Blunt",
	attack: true,
	weight: 3
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Soul Gem",
	set: set.dragonspire,
	types: "Item Light",
	light: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Soul Jar",
	set: set.doom,
	types: "Weapon Magic",
	magicAttack: true,
	weight: 3
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Spear",
	set: set.base,
	types: "Weapon Edged",
	attack: true,
	weight: 4
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Spirit Blast",
	set: set.doom,
	types: "Spell",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Spirit Hunter",
	set: set.doom,
	types: "Villager Mercenary",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Spoiled Food",
	set: set.dragonspire,
	types: "Item Food",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Stalking Spell",
	set: set.thorn,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Tavern Brawl",
	set: set.wrath,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Tax Collector",
	set: set.wrath,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Thieves' Blade",
	set: set.thorn,
	types: "Weapon Edged",
	attack: true,
	weight: 3
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Thunder Ring",
	set: set.dragonspire,
	types: "Item Light Magic",
	light: true,
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Time Bend",
	set: set.thorn,
	types: "Spell"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Toryn Gauntlet",
	set: set.dragonspire,
	types: "Weapon Magic",
	magicAttack: true,
	weight: 2
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Town Guard",
	set: set.base,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Trader",
	set: set.dragonspire,
	types: "Villager Mercenary"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Trainer",
	set: set.base,
	types: "Villager"
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Unicorn Steak",
	set: set.thorn,
	types: "Item Food",
	magicAttack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Village Mob",
	set: set.thorn,
	types: "Villager Mercenary",
	attack: true
});
cards["Village"][cards["Village"].length]=new Card({
	name: "Warhammer",
	set: set.base,
	types: "Weapon Blunt",
	weight: 5
});

heroes=new Array();
heroes[heroes.length]=new Card({
	name: "Amazon",
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Belzur",
	set: set.dragonspire,
	types: "Cleric",
	strength: 4,
	destroysDiease: true,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Blind",
	set: set.wrath,
	types: "Fighter Cleric",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_light_item, 2)
	]
});
heroes[heroes.length]=new Card({
	name: "Cabal",
	set: set.dragonspire,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
heroes[heroes.length]=new Card({
	name: "Chalice",
	set: set.base,
	types: "Fighter Cleric",
	strength: 5,
	attack: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Chulian",
	set: set.dragonspire,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Clan",
	set: set.promo,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Deep",
	set: set.doom,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Diin",
	set: set.wrath,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Drunari",
	set: set.doom,
	types: "Thief",
	strength: 3,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Divine",
	set: set.wrath,
	types: "Cleric",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Dwarf",
	set: set.base,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
		new Requirement(req_village_edged_weapon),
		new Requirement(req_village_nonedged_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Elf",
	set: set.base,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	light: true,
	removesMonstersFromHall: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Evoker",
	set: set.dragonspire,
	types: "Archer Wizard",
	strength: 4,
	attack: true,
	light: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Feayn",
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Flame",
	set: set.dragonspire,
	types: "Fighter Wizard",
	strength: 5,
	attack: true,
	light: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Gangland",
	set: set.wrath,
	types: "Thief",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Gohlen",
	set: set.wrath,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Gorinth",
	set: set.dragonspire,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Half-Orc",
	set: set.dragonspire,
	types: "Fighter Thief",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_food),
		new Requirement(req_village_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Lorigg",
	set: set.base,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Outlands",
	set: set.base,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
heroes[heroes.length]=new Card({
	name: "Phalanx",
	set: set.dragonspire,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Redblade",
	set: set.base,
	types: "Fighter Thief",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Regian",
	set: set.base,
	types: "Cleric",
	strength: 4,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Runespawn",
	set: set.wrath,
	types: "Thief Wizard",
	strength: 5,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
heroes[heroes.length]=new Card({
	name: "Selurin",
	set: set.base,
	types: "Wizard",
	strength: 2,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell_magic_attack),
		new Requirement(req_village_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Sidhe",
	set: set.doom,
	types: "Cleric",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Slynn",
	set: set.doom,
	types: "Fighter Archer",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Stoneguard",
	set: set.dragonspire,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon),
		new Requirement(req_village_mercenary)
	]
});
heroes[heroes.length]=new Card({
	name: "Tempest",
	set: set.doom,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Terakian",
	set: set.dragonspire,
	types: "Fighter Cleric",
	strength: 3,
	attack: true,
	destroyDisease: true,
	requirements: [
		new Requirement(req_village_villager)
	]
});
heroes[heroes.length]=new Card({
	name: "Tholis",
	set: set.doom,
	types: "Thief Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Thyrian",
	set: set.base,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
heroes[heroes.length]=new Card({
	name: "Toryn",
	set: set.wrath,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon, 2)
	]
});
heroes[heroes.length]=new Card({
	name: "Verdan",
	set: set.doom,
	types: "Fighter Thief",
	strength: 5,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
heroes[heroes.length]=new Card({
	name: "Veteran",
	set: set.dragonspire,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
	]
});

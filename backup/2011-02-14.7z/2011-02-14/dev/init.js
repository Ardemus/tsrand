//Used to determine whether a hero is 'strong.' Based on level 1 hero.
var heroStrengthThreshold=5;

var numberOfMonsters=3;
var numberOfHeroes=4;
var numberOfVillageCards=8;
var trapChance=.5;
var treasureChance=.5;
var guardianChance=.5;
var settingChance=.5;
var diseaseChance=.5;
var soloGame=false;

function getOptions() {
	diseaseChance=document.getElementById("diseaseSelect").value;
	guardianChance=document.getElementById("guardianSelect").value;
	settingChance=document.getElementById("settingSelect").value;
	trapChance=document.getElementById("trapSelect").value;
	treasureChance=document.getElementById("treasureSelect").value;
	numberOfMonsters=document.getElementById("monstersSelect").value;
	numberOfHeroes=document.getElementById("heroesSelect").value;
	numberOfVillageCards=document.getElementById("villageSelect").value;
	soloGame=document.getElementById("soloGame").checked;
}

//Types of conditions
type={
	disease: "Disease",
	dungeon: "Dungeon",
	feature: "Feature",
	hero: "Hero",
	village: "Village"
}

//Sets
set={
	base: "Base",
	doom: "Doomgate Legion",
	dragonspire: "Dragonspire",
	promo: "Promo",
	wrath: "Wrath Of The Elements"
}

//Logging stuff
indent=0;
function log(s) {
	if (document.getElementById("showLog").checked) {
		for (logi=0; logi<indent; logi++)
			document.getElementById("log").value+="\t";
		document.getElementById("log").value+=s+"\n";
	}
}

//Fisher-Yates shuffle
//Via http://sedition.com/perl/javascript-fy.html
function fisherYates ( myArray ) {
  var i = myArray.length;
  if ( i == 0 ) return false;
  while ( --i ) {
     var j = Math.floor( Math.random() * ( i + 1 ) );
     var tempi = myArray[i];
     var tempj = myArray[j];
     myArray[i] = tempj;
     myArray[j] = tempi;
   }
}

//Clone object
//Via http://keithdevens.com/weblog/archive/2007/Jun/07/javascript.clone
function clone(obj){
    if(obj == null || typeof(obj) != 'object')
        return obj;

    var temp = new obj.constructor(); // changed (twice)
    for(var key in obj)
        temp[key] = clone(obj[key]);

    return temp;
}

//Start cookie stuff
cookieName="tsrandOptions"
function restoreOptions() {
	log("Restoring cookie")
	indent++;
	cookie=$.cookie(cookieName);
	log("Cookie loaded: "+cookie);
	if (cookie) {
		opt=JSON.parse(cookie);
		for (var id in opt) {
			log("Loaded: "+id+" = "+opt[id]);
			if (document.getElementById(id)) {
				element=document.getElementById(id);
				if (opt[id].indexOf("checkbox")==0)
					element.checked=(opt[id]=="checkbox:true");
				else
					element.value=opt[id];
			}
		}
	}
	indent--;
}
function saveOptions() {
	log("Saving cookie")
	opt={ add: function(what) {
			if (document.getElementById(what)) {
				element=document.getElementById(what);
				if (element.type=="checkbox")
					this[what]="checkbox:"+element.checked;
				else
					this[what]=element.value;
			}
		}
	}
	opt.add("diseaseSelect");
	opt.add("guardianSelect");
	opt.add("settingSelect");
	opt.add("trapSelect");
	opt.add("treasureSelect");
	opt.add("monstersSelect");
	opt.add("heroesSelect");
	opt.add("villageSelect");
	opt.add("soloGame");
	opt.add("useConditions");
	opt.add("showLog");
	for (var i in set)
		opt.add(getId(set[i]));
	for (var i=0; i<monsters.length; i++)
		opt.add(getId(monsters[i]));
	for (var i=0; i<guardians.length; i++)
		opt.add(getId(guardians[i]));
	for (var i=0; i<traps.length; i++)
		opt.add(getId(traps[i]));
	for (var i=0; i<heroes.length; i++)
		opt.add(getId(heroes[i]));
	for (var i=0; i<village.length; i++)
		opt.add(getId(village[i]));
	indent++;
	for (i in opt)
		log(i+": "+opt[i]);
	indent--;
	cookie=JSON.stringify(opt)
	log("Cookie: "+cookie);
	$.cookie(cookieName, cookie, { expires: 365 });
}
$(document).ready(function() {
	restoreOptions();
	//Make sure everything is styled as appropriate
	for (var i in set)
		setClicked(getId(set[i]));
	for (var i=0; i<monsters.length; i++)
		styleCard(getId(monsters[i]));
	for (var i=0; i<guardians.length; i++)
		styleCard(getId(guardians[i]));
	for (var i=0; i<traps.length; i++)
		styleCard(getId(traps[i]));
	for (var i=0; i<treasures.length; i++)
		styleCard(getId(treasures[i]));
	for (var i=0; i<heroes.length; i++)
		styleCard(getId(heroes[i]));
	for (var i=0; i<village.length; i++)
		styleCard(getId(village[i]));
	for (var i=0; i<settings.length; i++)
		styleCard(getId(settings[i]));
	toggleLog();
});
//End cookie stuff

function validate(card) {
	var toReturn = ((document.getElementById(getId(card)).value=="Maybe")
		&& (document.getElementById(getId(card.set)).checked));
	toReturn=toReturn&&(!soloGame || isAppropriateForSinglePlayer(card));
	
	return toReturn;
}

var monsterDeck;
var trapDeck;
var treasureDeck;
var guardianDeck;
var heroDeck;
var villageDeck;
var settingDeck;

function buildDeck(source) {
	toReturn=new Array();
	for (var i=0; i<source.length; i++)
		if (validate(source[i]))
			toReturn[toReturn.length]=i;
	fisherYates(toReturn);
	return toReturn;
}
function buildDecks() {
	heroDeck=buildDeck(heroes);
	guardianDeck=buildDeck(guardians);
	monsterDeck=buildDeck(monsters);
	settingDeck=buildDeck(settings);
	trapDeck=buildDeck(traps);
	treasureDeck=buildDeck(treasures);
	villageDeck=buildDeck(village);
}

function printList(listId, header, array) {
	list=document.getElementById(listId);
	list.innerHTML+="<li class='listHeader'>"+header+"</li>";
	for (key in array)
		if (array[key].name)
			list.innerHTML+="<li class='"+getClass(array[key])+" noSelect'><select id='"+getId(array[key])+"' onchange='javascript:saveOptions()' checked='checked'><option value='No'>No</option><option value='Maybe' selected='selected'>Maybe</option><option value='Yes'>Yes</option></select><label for='"+getId(array[key])+"' class='YesNoMaybe'>"+array[key]+"</laberl></li>";
		else
			list.innerHTML+="<li class='"+getClass(array[key])+" noSelect'><input type='checkbox' id='"+getId(array[key])+"' onclick='"+getClickEvent(array[key])+"' checked='checked'><label for='"+getId(array[key])+"'>"+array[key]+"</laberl></li>";
}

function getId(input) {
	name=input;
	prefix="set";
	if (input.name) {
		name=input.name;
		prefix="card";
	}
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	stripped=name.replace(invalidChars,'');
	return prefix+stripped.charAt(0).toUpperCase()+stripped.substring(1);
}

function getClass(input, noPrefix) {
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	prefix="";
	if (input.name) {
		stripped=input.set.replace(invalidChars,'');
		if (!noPrefix)
			prefix="card ";
		return prefix+stripped;
	} else {
		stripped=input.replace(invalidChars,'');
		if (!noPrefix)
			prefix="set ";
		return prefix+stripped;
	}
}

function getClickEvent(input) {
	if (input.name)
		return 'javascript:cardClicked("'+getId(input)+'")';
	else
		return 'javascript:setClicked("'+getId(input)+'")';
}

function styleCard(which) {
	var select=$("#"+which);
	var label=$("label[for='"+which+"']");
	var val=select.val();
	select.parent().removeClass("disabled");
	label.removeClass("required");
	if (val=="No")
		select.parent().addClass("disabled");
	else if (val=="Yes")
		label.addClass("required");
}

function setClicked(which) {
	setClass="."+which.substring(3); //Strip the "set" prefix
	if (document.getElementById(which).checked) {
		$(".card"+setClass).removeClass("hidden");
		$("#"+which).parent().removeClass("disabled");
	} else {
		$(".card"+setClass).addClass("hidden");
		$("#"+which).parent().addClass("disabled");
	}
	saveOptions();
}

function isAppropriateForSinglePlayer(card) {
	return !card.removesMonstersFromHall;
}

function randomize() {
	var settingList=document.getElementById("settingList");
	var dungeonList=document.getElementById("dungeonList");
	var heroList=document.getElementById("heroList");
	var villageList=document.getElementById("villageList");
	gameSet=getGameSet();
	dungeonList.innerHTML="<li class='listHeader'>Dungeon Deck</li>";
	heroList.innerHTML="<li class='listHeader'>Heroes</li>";
	villageList.innerHTML="<li class='listHeader'>Village Cards</li>";
	
	if (gameSet.settingDeck.length>0) {
		$(settingList).removeClass("hidden");
		settingList.innerHTML="<li class='listHeader'>Setting</li>";
		for (var i=0; i<gameSet.settingDeck.length; i++)
			settingList.innerHTML+="<li class='gameCard setting "+getClass(gameSet.settingDeck[i].set, true)+"'>"+gameSet.settingDeck[i].name+"</li>";
	} else
		$(settingList).addClass("hidden");
	for (var i=0; i<gameSet.dungeonDeck.length; i++)
		dungeonList.innerHTML+="<li class='gameCard monster "+getClass(gameSet.dungeonDeck[i].set, true)+"'>"+gameSet.dungeonDeck[i].name+"</li>";
	if (gameSet.useSpecialDiseases)
		dungeonList.innerHTML+="<li>Use special diseases</li>";
	for (var i=0; i<gameSet.heroes.length; i++)
		heroList.innerHTML+="<li class='gameCard hero "+getClass(gameSet.heroes[i].set, true)+"'>"+gameSet.heroes[i].name+"</li>";
	for (var i=0; i<gameSet.village.length; i++)
		villageList.innerHTML+="<li class='gameCard village "+getClass(gameSet.village[i].set, true)+"'>"+gameSet.village[i].name+"</li>";
}

function toggleLog() {
	saveOptions();
	if (document.getElementById("showLog").checked)
		$("#log").removeClass("hidden");
	else
		$("#log").addClass("hidden");
}

//iOS label fix
//via http://www.thewatchmakerproject.com/blog/how-to-fix-the-broken-ipad-form-label-click-issue/
if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/iPad/i)) {
	$(document).ready(function () {
		$('label[for]').click(function () {
			var el = $(this).attr('for');
			if ($('#' + el + '[type=radio], #' + el + '[type=checkbox]').attr('selected', !$('#' + el).attr('selected'))) {
				return;
			} else {
				$('#' + el)[0].focus();
			}
		});
	});
}

//Enables the yes/no/maybe tri-state boxes
$(document).ready(function() {
	$(".YesNoMaybe").click(function(event) {
		event.preventDefault();
		var id = $(this).attr('for');
		var select=$("#"+id);
		var label=$("label[for='"+id+"']");
		var val=select.val();
		select.parent().removeClass("disabled");
		label.removeClass("required");
		//alert(val);
		if (val=="No") {
			select.val("Maybe");
		} else if (val=="Maybe") {
			select.val("Yes");
			label.addClass("required");
		} else {
			select.val("No");
			select.parent().addClass("disabled");
		}
		saveOptions();
	})
});

//Disable text selection on elements with class noSelect
//Via http://chris-barr.com/entry/disable_text_selection_with_jquery/
$(function(){
	$.extend($.fn.disableTextSelect = function() {
		return this.each(function(){
			if($.browser.mozilla){//Firefox
				$(this).css('MozUserSelect','none');
			}else if($.browser.msie){//IE
				$(this).bind('selectstart',function(){return false;});
			}else{//Opera, etc.
				$(this).mousedown(function(){return false;});
			}
		});
	});
	$('.noSelect').disableTextSelect();//No text selection on elements with a class of 'noSelect'
});

//Set sizing
function resize() {
	width=Math.round($("body").width()*.95);
	minWidth=320; //minimum width *per column* required before it can be side-by-side
	if (width>minWidth*2)
		$(".container, #log").width("50%");
	else
		$(".container, #log").width("100%");
}
$(document).ready(function() {
	resize();
});
$(window).resize(function(){
	resize();
});

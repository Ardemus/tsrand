allCards=new Array();
var gameSetHTML="";
var cardListHTML="";
for (var i=0; i<cardTypes.length; i++) {
	var type=cardTypes[i];
	gameSetHTML += '<ul id="'+cardTypes[i].name+'List" class="cardList"></ul>';
	cardListHTML += printList(type);
}
document.getElementById("lists").innerHTML = gameSetHTML;
document.getElementById("filterSetList").innerHTML = printSetList();
document.getElementById("filterCardList").innerHTML = cardListHTML;

restoreOptions();
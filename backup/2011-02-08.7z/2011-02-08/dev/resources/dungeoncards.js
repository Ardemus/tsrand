monsters=new Array();
monsters[monsters.length]=new Card({
	name: "Abyssal",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_wizard), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Abyssal * Thunderspawn",
	set: set.doom,
	requirements: [
		new Requirement(req_hero_archer), 
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_wizard)
	]
});
monsters[monsters.length]=new Card({
	name: "Cultist * Humanoid",
	set: set.doom,
	requirements: [
		new Requirement(req_village_item), 
		new Requirement(req_village_weapon), 
		new Requirement(req_village_spell) 
	]
});
monsters[monsters.length]=new Card({
	name: "Doomknight * Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_fighter), 
		new Requirement(req_village_light), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Dragon",
	set: set.base,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Nature",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Pain",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Enchanted",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Evil Druid * Humanoid",
	set: set.doom,
	requirements: [
		new Requirement(req_disease_special),
		new Requirement(req_hero_cleric)
	]
});
monsters[monsters.length]=new Card({
	name: "Golem",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength)
	]
});
monsters[monsters.length]=new Card({
	name: "Horde",
	set: set.wrath,
	requirements: [
	]
});
monsters[monsters.length]=new Card({
	name: "Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Ooze",
	set: set.base,
	requirements: [
		new Requirement(req_village_edged_weapon), 
		new Requirement(req_village_food), 
		new Requirement(req_village_nonedged_weapon), 
	]
});
monsters[monsters.length]=new Card({
	name: "The Swarm",
	set: set.doom,
	requirements: [
		new Requirement(req_disease_special),
		new Requirement(req_hero_cleric)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Doom",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Spirit",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Stormwraith",
	set: set.doom,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell)
	]
});


traps=new Array();
traps[traps.length]=new Card({
	name: "Trap * Death",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief)
	]
});
traps[traps.length]=new Card({
	name: "Trap * Dire",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief),
		new Requirement(req_hero_cleric)
	]
});

guardians=new Array();
guardians[guardians.length]=new Card({
	name: "Dark Champion",
	set: set.wrath,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Death Sentinel",
	set: set.promo,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Unholy Guardian",
	set: set.doom,
	requirements: [
	]
});

treasures=new Array();
treasures[treasures.length]=new Card({
	name: "Amulet Treasures",
	set: set.doom,
	requirements: [
	]
});
treasures[treasures.length]=new Card({
	name: "Ulbrick's Treasures",
	set: set.doom,
	requirements: [
	]
});

req_hero_attack=new Condition({
	name: "req_hero_attack",
	type: type.hero,
	match: function(card) {
		return (card.has("attack"))
	}
});

req_hero_cleric=new Condition({
	name: "req_hero_cleric",
	type: type.hero,
	match: function(card) {
		return card.is("Cleric")
	}
});

req_hero_fighter=new Condition({
	name: "req_hero_fighter",
	type: type.hero,
	match: function(card) {
		return card.is("Fighter")
	}
});

req_hero_magic_attack=new Condition({
	name: "req_hero_magic_attack",
	type: type.hero,
	match: function(card) {
		return (card.has("magicAttack"))
	}
});

req_hero_strength=new Condition({
	name: "req_hero_strength",
	type: type.hero,
	match: function(card) {
		return (card.has("strength") > heroStrengthThreshold)
	}
});

req_hero_thief=new Condition({
	name: "req_hero_thief",
	type: type.hero,
	match: function(card) {
		return card.is("Thief")
	}
});

req_hero_wizard=new Condition({
	name: "req_hero_wizard",
	type: type.hero,
	match: function(card) {
		return card.is("Wizard")
	}
});

req_village_attack=new Condition({
	name: "req_village_attack",
	type: type.village,
	match: function(card) {
		return (card.has("attack"))
	}
});

req_village_edged_weapon=new Condition({
	name: "req_village_edged_weapon",
	type: type.village,
	match: function(card) {
		return (card.is("Weapon") && card.is("Edged"))
	}
});

req_village_food=new Condition({
	name: "req_village_food",
	type: type.village,
	match: function(card) {
		return card.is("Food")
	}
});

req_village_item=new Condition({
	name: "req_village_item",
	type: type.village,
	match: function(card) {
		return card.is("Item")
	}
});

req_village_light=new Condition({
	name: "req_village_light",
	type: type.village,
	match: function(card) {
		return (card.has("light"))
	}
});

req_village_light_item=new Condition({
	name: "req_village_light_item",
	type: type.village,
	match: function(card) {
		return ((card.has("light")) && card.is("Item"))
	}
});

req_village_magic_attack=new Condition({
	name: "req_village_magic_attack",
	type: type.village,
	match: function(card) {
		return (card.has("magicAttack"))
	}
});

req_village_nonedged_weapon=new Condition({
	name: "req_village_nonedged_weapon",
	type: type.village,
	match: function(card) {
		return (card.is("Weapon") && !card.is("Edged"))
	}
});

req_village_spell=new Condition({
	name: "req_village_spell",
	type: type.village,
	match: function(card) {
		return card.is("Spell")
	}
});

req_village_spell_magic_attack=new Condition({
	name: "req_village_spell_magic_attack",
	type: type.village,
	match: function(card) {
		return ((card.has("magicAttack")) && card.is("Spell"))
	}
});

req_village_strength=new Condition({
	name: "req_village_strength",
	type: type.village,
	match: function(card) {
		return (card.has("strength"))
	}
});

req_village_weapon=new Condition({
	name: "req_village_weapon",
	type: type.village,
	match: function(card) {
		return card.is("Weapon")
	}
});
/**
 * Cookie plugin
 *
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */

/**
 * Create a cookie with the given name and value and other optional parameters.
 *
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Set the value of a cookie.
 * @example $.cookie('the_cookie', 'the_value', { expires: 7, path: '/', domain: 'jquery.com', secure: true });
 * @desc Create a cookie with all available options.
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Create a session cookie.
 * @example $.cookie('the_cookie', null);
 * @desc Delete a cookie by passing null as value. Keep in mind that you have to use the same path and domain
 *       used when the cookie was set.
 *
 * @param String name The name of the cookie.
 * @param String value The value of the cookie.
 * @param Object options An object literal containing key/value pairs to provide optional cookie attributes.
 * @option Number|Date expires Either an integer specifying the expiration date from now on in days or a Date object.
 *                             If a negative value is specified (e.g. a date in the past), the cookie will be deleted.
 *                             If set to null or omitted, the cookie will be a session cookie and will not be retained
 *                             when the the browser exits.
 * @option String path The value of the path atribute of the cookie (default: path of page that created the cookie).
 * @option String domain The value of the domain attribute of the cookie (default: domain of page that created the cookie).
 * @option Boolean secure If true, the secure attribute of the cookie will be set and the cookie transmission will
 *                        require a secure protocol (like HTTPS).
 * @type undefined
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */

/**
 * Get the value of a cookie with the given name.
 *
 * @example $.cookie('the_cookie');
 * @desc Get the value of a cookie.
 *
 * @param String name The name of the cookie.
 * @return The value of the cookie.
 * @type String
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};/*
    http://www.JSON.org/json2.js
    2010-08-25

    Public Domain.

    NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

    See http://www.JSON.org/js.html


    This code should be minified before deployment.
    See http://javascript.crockford.com/jsmin.html

    USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
    NOT CONTROL.


    This file creates a global JSON object containing two methods: stringify
    and parse.

        JSON.stringify(value, replacer, space)
            value       any JavaScript value, usually an object or array.

            replacer    an optional parameter that determines how object
                        values are stringified for objects. It can be a
                        function or an array of strings.

            space       an optional parameter that specifies the indentation
                        of nested structures. If it is omitted, the text will
                        be packed without extra whitespace. If it is a number,
                        it will specify the number of spaces to indent at each
                        level. If it is a string (such as '\t' or '&nbsp;'),
                        it contains the characters used to indent at each level.

            This method produces a JSON text from a JavaScript value.

            When an object value is found, if the object contains a toJSON
            method, its toJSON method will be called and the result will be
            stringified. A toJSON method does not serialize: it returns the
            value represented by the name/value pair that should be serialized,
            or undefined if nothing should be serialized. The toJSON method
            will be passed the key associated with the value, and this will be
            bound to the value

            For example, this would serialize Dates as ISO strings.

                Date.prototype.toJSON = function (key) {
                    function f(n) {
                        // Format integers to have at least two digits.
                        return n < 10 ? '0' + n : n;
                    }

                    return this.getUTCFullYear()   + '-' +
                         f(this.getUTCMonth() + 1) + '-' +
                         f(this.getUTCDate())      + 'T' +
                         f(this.getUTCHours())     + ':' +
                         f(this.getUTCMinutes())   + ':' +
                         f(this.getUTCSeconds())   + 'Z';
                };

            You can provide an optional replacer method. It will be passed the
            key and value of each member, with this bound to the containing
            object. The value that is returned from your method will be
            serialized. If your method returns undefined, then the member will
            be excluded from the serialization.

            If the replacer parameter is an array of strings, then it will be
            used to select the members to be serialized. It filters the results
            such that only members with keys listed in the replacer array are
            stringified.

            Values that do not have JSON representations, such as undefined or
            functions, will not be serialized. Such values in objects will be
            dropped; in arrays they will be replaced with null. You can use
            a replacer function to replace those with JSON values.
            JSON.stringify(undefined) returns undefined.

            The optional space parameter produces a stringification of the
            value that is filled with line breaks and indentation to make it
            easier to read.

            If the space parameter is a non-empty string, then that string will
            be used for indentation. If the space parameter is a number, then
            the indentation will be that many spaces.

            Example:

            text = JSON.stringify(['e', {pluribus: 'unum'}]);
            // text is '["e",{"pluribus":"unum"}]'


            text = JSON.stringify(['e', {pluribus: 'unum'}], null, '\t');
            // text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

            text = JSON.stringify([new Date()], function (key, value) {
                return this[key] instanceof Date ?
                    'Date(' + this[key] + ')' : value;
            });
            // text is '["Date(---current time---)"]'


        JSON.parse(text, reviver)
            This method parses a JSON text to produce an object or array.
            It can throw a SyntaxError exception.

            The optional reviver parameter is a function that can filter and
            transform the results. It receives each of the keys and values,
            and its return value is used instead of the original value.
            If it returns what it received, then the structure is not modified.
            If it returns undefined then the member is deleted.

            Example:

            // Parse the text. Values that look like ISO date strings will
            // be converted to Date objects.

            myData = JSON.parse(text, function (key, value) {
                var a;
                if (typeof value === 'string') {
                    a =
/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
                    if (a) {
                        return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4],
                            +a[5], +a[6]));
                    }
                }
                return value;
            });

            myData = JSON.parse('["Date(09/09/2001)"]', function (key, value) {
                var d;
                if (typeof value === 'string' &&
                        value.slice(0, 5) === 'Date(' &&
                        value.slice(-1) === ')') {
                    d = new Date(value.slice(5, -1));
                    if (d) {
                        return d;
                    }
                }
                return value;
            });


    This is a reference implementation. You are free to copy, modify, or
    redistribute.
*/

/*jslint evil: true, strict: false */

/*members "", "\b", "\t", "\n", "\f", "\r", "\"", JSON, "\\", apply,
    call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
    getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
    lastIndex, length, parse, prototype, push, replace, slice, stringify,
    test, toJSON, toString, valueOf
*/


// Create a JSON object only if one does not already exist. We create the
// methods in a closure to avoid creating global variables.

if (!this.JSON) {
    this.JSON = {};
}

(function () {

    function f(n) {
        // Format integers to have at least two digits.
        return n < 10 ? '0' + n : n;
    }

    if (typeof Date.prototype.toJSON !== 'function') {

        Date.prototype.toJSON = function (key) {

            return isFinite(this.valueOf()) ?
                   this.getUTCFullYear()   + '-' +
                 f(this.getUTCMonth() + 1) + '-' +
                 f(this.getUTCDate())      + 'T' +
                 f(this.getUTCHours())     + ':' +
                 f(this.getUTCMinutes())   + ':' +
                 f(this.getUTCSeconds())   + 'Z' : null;
        };

        String.prototype.toJSON =
        Number.prototype.toJSON =
        Boolean.prototype.toJSON = function (key) {
            return this.valueOf();
        };
    }

    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        gap,
        indent,
        meta = {    // table of character substitutions
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"' : '\\"',
            '\\': '\\\\'
        },
        rep;


    function quote(string) {

// If the string contains no control characters, no quote characters, and no
// backslash characters, then we can safely slap some quotes around it.
// Otherwise we must also replace the offending characters with safe escape
// sequences.

        escapable.lastIndex = 0;
        return escapable.test(string) ?
            '"' + string.replace(escapable, function (a) {
                var c = meta[a];
                return typeof c === 'string' ? c :
                    '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"' :
            '"' + string + '"';
    }


    function str(key, holder) {

// Produce a string from holder[key].

        var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];

// If the value has a toJSON method, call it to obtain a replacement value.

        if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }

// If we were called with a replacer function, then call the replacer to
// obtain a replacement value.

        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }

// What happens next depends on the value's type.

        switch (typeof value) {
        case 'string':
            return quote(value);

        case 'number':

// JSON numbers must be finite. Encode non-finite numbers as null.

            return isFinite(value) ? String(value) : 'null';

        case 'boolean':
        case 'null':

// If the value is a boolean or null, convert it to a string. Note:
// typeof null does not produce 'null'. The case is included here in
// the remote chance that this gets fixed someday.

            return String(value);

// If the type is 'object', we might be dealing with an object or an array or
// null.

        case 'object':

// Due to a specification blunder in ECMAScript, typeof null is 'object',
// so watch out for that case.

            if (!value) {
                return 'null';
            }

// Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

// Is the value an array?

            if (Object.prototype.toString.apply(value) === '[object Array]') {

// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }

// Join all of the elements together, separated with commas, and wrap them in
// brackets.

                v = partial.length === 0 ? '[]' :
                    gap ? '[\n' + gap +
                            partial.join(',\n' + gap) + '\n' +
                                mind + ']' :
                          '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }

// If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    k = rep[i];
                    if (typeof k === 'string') {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {

// Otherwise, iterate through all of the keys in the object.

                for (k in value) {
                    if (Object.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }

// Join all of the member texts together, separated with commas,
// and wrap them in braces.

            v = partial.length === 0 ? '{}' :
                gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' +
                        mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

// If the JSON object does not yet have a stringify method, give it one.

    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (value, replacer, space) {

// The stringify method takes a value and an optional replacer, and an optional
// space parameter, and returns a JSON text. The replacer can be a function
// that can replace values, or an array of strings that will select the keys.
// A default replacer method can be provided. Use of the space parameter can
// produce text that is more easily readable.

            var i;
            gap = '';
            indent = '';

// If the space parameter is a number, make an indent string containing that
// many spaces.

            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }

// If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === 'string') {
                indent = space;
            }

// If there is a replacer, it must be a function or an array.
// Otherwise, throw an error.

            rep = replacer;
            if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                     typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }

// Make a fake root object containing our value under the key of ''.
// Return the result of stringifying the value.

            return str('', {'': value});
        };
    }


// If the JSON object does not yet have a parse method, give it one.

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {

// The parse method takes a text and an optional reviver function, and returns
// a JavaScript value if the text is a valid JSON text.

            var j;

            function walk(holder, key) {

// The walk method is used to recursively walk the resulting structure so
// that modifications can be made.

                var k, v, value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }


// Parsing happens in four stages. In the first stage, we replace certain
// Unicode characters with escape sequences. JavaScript handles many characters
// incorrectly, either silently deleting them, or treating them as line endings.

            text = String(text);
            cx.lastIndex = 0;
            if (cx.test(text)) {
                text = text.replace(cx, function (a) {
                    return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }

// In the second stage, we run the text against regular expressions that look
// for non-JSON patterns. We are especially concerned with '()' and 'new'
// because they can cause invocation, and '=' because it can cause mutation.
// But just to be safe, we want to reject all unexpected forms.

// We split the second stage into 4 regexp operations in order to work around
// crippling inefficiencies in IE's and Safari's regexp engines. First we
// replace the JSON backslash pairs with '@' (a non-JSON character). Second, we
// replace all simple value tokens with ']' characters. Third, we delete all
// open brackets that follow a colon or comma or that begin the text. Finally,
// we look to see that the remaining characters are only whitespace or ']' or
// ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.

            if (/^[\],:{}\s]*$/
.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
.replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

// In the third stage we use the eval function to compile the text into a
// JavaScript structure. The '{' operator is subject to a syntactic ambiguity
// in JavaScript: it can begin a block or an object literal. We wrap the text
// in parens to eliminate the ambiguity.

                j = eval('(' + text + ')');

// In the optional fourth stage, we recursively walk the new structure, passing
// each name/value pair to a reviver function for possible transformation.

                return typeof reviver === 'function' ?
                    walk({'': j}, '') : j;
            }

// If the text is not JSON parseable, then a SyntaxError is thrown.

            throw new SyntaxError('JSON.parse');
        };
    }
}());
//Used to determine whether a hero is 'strong.' Based on level 1 hero.
var heroStrengthThreshold=5;

var numberOfMonsters=3;
var numberOfHeroes=4;
var numberOfVillageCards=8;
var trapChance=1;
var guardianChance=.5;
var soloGame=false;

function getOptions() {
	guardianChance=document.getElementById("guardianSelect").value;
	trapChance=document.getElementById("trapSelect").value;
	numberOfMonsters=document.getElementById("monstersSelect").value;
	numberOfHeroes=document.getElementById("heroesSelect").value;
	numberOfVillageCards=document.getElementById("villageSelect").value;
	soloGame=document.getElementById("soloGame").checked;
}

//Types of conditions
type={
	dungeon: "Dungeon",
	feature: "Feature",
	hero: "Hero",
	village: "Village"
}

//Sets
set={
	base: "Base",
	promo: "Promo",
	wrath: "Wrath Of The Elements"
}

//Logging stuff
indent=0;
function log(s) {
	if (document.getElementById("showLog").checked) {
		for (logi=0; logi<indent; logi++)
			document.getElementById("log").value+="\t";
		document.getElementById("log").value+=s+"\n";
	}
}

//Fisher-Yates shuffle
//Via http://sedition.com/perl/javascript-fy.html
function fisherYates ( myArray ) {
  var i = myArray.length;
  if ( i == 0 ) return false;
  while ( --i ) {
     var j = Math.floor( Math.random() * ( i + 1 ) );
     var tempi = myArray[i];
     var tempj = myArray[j];
     myArray[i] = tempj;
     myArray[j] = tempi;
   }
}

//Clone object
//Via http://keithdevens.com/weblog/archive/2007/Jun/07/javascript.clone
function clone(obj){
    if(obj == null || typeof(obj) != 'object')
        return obj;

    var temp = new obj.constructor(); // changed (twice)
    for(var key in obj)
        temp[key] = clone(obj[key]);

    return temp;
}

//Cookie stuff
cookieName="tsrandOptions"
function restoreOptions() {
	log("Restoring cookie")
	indent++;
	cookie=$.cookie(cookieName);
	log("Cookie loaded: "+cookie);
	if (cookie) {
		opt=JSON.parse(cookie);
		for (var id in opt) {
			log("Loaded: "+id+" = "+opt[id]);
			if (document.getElementById(id)) {
				element=document.getElementById(id);
				if (opt[id].indexOf("checkbox")==0)
					element.checked=(opt[id]=="checkbox:true");
				else
					element.value=opt[id];
			}
		}
	}
	indent--;
}
function saveOptions() {
	log("Saving cookie")
	opt={ add: function(what) {
			if (document.getElementById(what)) {
				element=document.getElementById(what);
				if (element.type=="checkbox")
					this[what]="checkbox:"+element.checked;
				else
					this[what]=element.value;
			}
		}
	}
	opt.add("guardianSelect");
	opt.add("trapSelect");
	opt.add("monstersSelect");
	opt.add("heroesSelect");
	opt.add("villageSelect");
	opt.add("soloGame");
	opt.add("useConditions");
	opt.add("showLog");
	for (var i in set)
		opt.add(getId(set[i]));
	for (var i=0; i<monsters.length; i++)
		opt.add(getId(monsters[i]));
	for (var i=0; i<guardians.length; i++)
		opt.add(getId(guardians[i]));
	for (var i=0; i<traps.length; i++)
		opt.add(getId(traps[i]));
	for (var i=0; i<heroes.length; i++)
		opt.add(getId(heroes[i]));
	for (var i=0; i<village.length; i++)
		opt.add(getId(village[i]));
	indent++;
	for (i in opt)
		log(i+": "+opt[i]);
	indent--;
	cookie=JSON.stringify(opt)
	log("Cookie: "+cookie);
	$.cookie(cookieName, cookie, { expires: 365 });
}
$(document).ready(function() {
	restoreOptions();
	//Make sure everything is styled as appropriate
	for (var i in set)
		setClicked(getId(set[i]));
	for (var i=0; i<monsters.length; i++)
		styleCard(getId(monsters[i]));
	for (var i=0; i<guardians.length; i++)
		styleCard(getId(guardians[i]));
	for (var i=0; i<traps.length; i++)
		styleCard(getId(traps[i]));
	for (var i=0; i<heroes.length; i++)
		styleCard(getId(heroes[i]));
	for (var i=0; i<village.length; i++)
		styleCard(getId(village[i]));
	toggleLog();
});
//End cookie stuff

function validate(card) {
	var toReturn = ((document.getElementById(getId(card)).value=="Maybe")
		&& (document.getElementById(getId(card.set)).checked));
	toReturn=toReturn&&(!soloGame || isAppropriateForSinglePlayer(card));
	
	return toReturn;
}

var monsterDeck;
var trapDeck;
var guardianDeck;
var heroDeck;
var villageDeck;

function buildDeck(source) {
	toReturn=new Array();
	for (var i=0; i<source.length; i++)
		if (validate(source[i]))
			toReturn[toReturn.length]=i;
	fisherYates(toReturn);
	return toReturn;
}
function buildDecks() {
	monsterDeck=buildDeck(monsters);
	trapDeck=buildDeck(traps);
	guardianDeck=buildDeck(guardians);
	heroDeck=buildDeck(heroes);
	villageDeck=buildDeck(village);
}

function printList(listId, header, array) {
	list=document.getElementById(listId);
	list.innerHTML+="<li class='listHeader'>"+header+"</li>";
	for (key in array)
		if (array[key].name)
			list.innerHTML+="<li class='"+getClass(array[key])+" noSelect'><select id='"+getId(array[key])+"' onchange='javascript:saveOptions()' checked='checked'><option value='No'>No</option><option value='Maybe' selected='selected'>Maybe</option><option value='Yes'>Yes</option></select><label for='"+getId(array[key])+"' class='YesNoMaybe'>"+array[key]+"</laberl></li>";
		else
			list.innerHTML+="<li class='"+getClass(array[key])+" noSelect'><input type='checkbox' id='"+getId(array[key])+"' onclick='"+getClickEvent(array[key])+"' checked='checked'><label for='"+getId(array[key])+"'>"+array[key]+"</laberl></li>";
}

function getId(input) {
	name=input;
	prefix="set";
	if (input.name) {
		name=input.name;
		prefix="card";
	}
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	stripped=name.replace(invalidChars,'');
	return prefix+stripped.charAt(0).toUpperCase()+stripped.substring(1);
}

function getClass(input, noPrefix) {
	invalidChars=/[^-A-Za-z0-9-_.]/g;
	prefix="";
	if (input.name) {
		stripped=input.set.replace(invalidChars,'');
		if (!noPrefix)
			prefix="card ";
		return prefix+stripped;
	} else {
		stripped=input.replace(invalidChars,'');
		if (!noPrefix)
			prefix="set ";
		return prefix+stripped;
	}
}

function getClickEvent(input) {
	if (input.name)
		return 'javascript:cardClicked("'+getId(input)+'")';
	else
		return 'javascript:setClicked("'+getId(input)+'")';
}

function styleCard(which) {
	var select=$("#"+which);
	var label=$("label[for='"+which+"']");
	var val=select.val();
	select.parent().removeClass("disabled");
	label.removeClass("required");
	if (val=="No")
		select.parent().addClass("disabled");
	else if (val=="Yes")
		label.addClass("required");
}

function setClicked(which) {
	setClass="."+which.substring(3); //Strip the "set" prefix
	if (document.getElementById(which).checked) {
		$(".card"+setClass).removeClass("hidden");
		$("#"+which).parent().removeClass("disabled");
	} else {
		$(".card"+setClass).addClass("hidden");
		$("#"+which).parent().addClass("disabled");
	}
	saveOptions();
}

function isAppropriateForSinglePlayer(card) {
	return !card.removesMonstersFromHall;
}

function randomize() {
		var dungeonList=document.getElementById("dungeonList");
		var heroList=document.getElementById("heroList");
		var villageList=document.getElementById("villageList");
		dungeonList.innerHTML="<li class='listHeader'>Dungeon Deck</li>";
		heroList.innerHTML="<li class='listHeader'>Heroes</li>";
		villageList.innerHTML="<li class='listHeader'>Village Cards</li>";
		gameSet=getGameSet();
		for (var i=0; i<gameSet.dungeonDeck.length; i++)
			dungeonList.innerHTML+="<li class='gameCard monster "+getClass(gameSet.dungeonDeck[i].set, true)+"'>"+gameSet.dungeonDeck[i].name+"</li>";
		for (var i=0; i<gameSet.heroes.length; i++)
			heroList.innerHTML+="<li class='gameCard hero "+getClass(gameSet.heroes[i].set, true)+"'>"+gameSet.heroes[i].name+"</li>";
		for (var i=0; i<gameSet.village.length; i++)
			villageList.innerHTML+="<li class='gameCard village "+getClass(gameSet.village[i].set, true)+"'>"+gameSet.village[i].name+"</li>";
	}

function toggleLog() {
	saveOptions();
	if (document.getElementById("showLog").checked)
		$("#log").removeClass("hidden");
	else
		$("#log").addClass("hidden");
}

//iOS label fix
//via http://www.thewatchmakerproject.com/blog/how-to-fix-the-broken-ipad-form-label-click-issue/
if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/iPad/i)) {
	$(document).ready(function () {
		$('label[for]').click(function () {
			var el = $(this).attr('for');
			if ($('#' + el + '[type=radio], #' + el + '[type=checkbox]').attr('selected', !$('#' + el).attr('selected'))) {
				return;
			} else {
				$('#' + el)[0].focus();
			}
		});
	});
}

//Enables the yes/no/maybe tri-state boxes
$(document).ready(function() {
	$(".YesNoMaybe").click(function(event) {
		event.preventDefault();
		var id = $(this).attr('for');
		var select=$("#"+id);
		var label=$("label[for='"+id+"']");
		var val=select.val();
		select.parent().removeClass("disabled");
		label.removeClass("required");
		//alert(val);
		if (val=="No") {
			select.val("Maybe");
		} else if (val=="Maybe") {
			select.val("Yes");
			label.addClass("required");
		} else {
			select.val("No");
			select.parent().addClass("disabled");
		}
		saveOptions();
	})
});

//Disable text selection on elements with class noSelect
//Via http://chris-barr.com/entry/disable_text_selection_with_jquery/
$(function(){
	$.extend($.fn.disableTextSelect = function() {
		return this.each(function(){
			if($.browser.mozilla){//Firefox
				$(this).css('MozUserSelect','none');
			}else if($.browser.msie){//IE
				$(this).bind('selectstart',function(){return false;});
			}else{//Opera, etc.
				$(this).mousedown(function(){return false;});
			}
		});
	});
	$('.noSelect').disableTextSelect();//No text selection on elements with a class of 'noSelect'
});function Condition(arg) {
	this.name=arg.name;
	if (!this.name)
		this.name="Condition missing name";
	this.type=arg.type;
	this.match=function(card) {
		if (card)
			return arg.match(card);
		else
			return false;
	}
	if (!this.match)
		this.match=function(){return true}

	this.toString=function(){return this.name;};
}

function Requirement(cond, qty) {
	if (cond) {
		this.match=cond.match;
		this.name=cond.name;
		this.type=cond.type;
		this.qty=1;
		if (qty)
			this.qty=qty;
		this.toString=function(){return this.name;};
	}
}


function Card(arg) {
	this.name=arg.name;
	if (!this.name)
		this.name="Missing name";
	this.set=arg.set;
	if (!this.set)
		this.set="";
	this.types=arg.types;
	if (!this.types)
		this.types="";
	this.light=arg.light;
	if (!this.light)
		this.light=false;
	this.strength=arg.strength;
	if (!this.strength)
		this.strength=false;
	this.attack=arg.attack;
	if (!this.attack)
		this.attack=false;
	this.magicAttack=arg.magicAttack;
	if (!this.magicAttack)
		this.magicAttack=false;
	this.removesMonstersFromHall=arg.removesMonstersFromHall;
	if (!this.removesMonstersFromHall)
		this.removesMonstersFromHall=false;
	this.requirements=arg.requirements;
	if (!this.requirements)
		this.requirements=[];
	this.is=function(what){
		if (this.types)
			return (this.types.indexOf(what)!=-1)
		else
			return false;
	}
	this.has=function(what){
		if (this[what])
			return this[what];
		else
			return false;
	}
	this.toString=function(){return this.name;};
}

function GameSet() {
	this.dungeonDeck=new Array();
	this.extraDungeonCards=0;
	for (var key in monsters)
		if (cardRequired(monsters[key]))
			this.dungeonDeck[this.dungeonDeck.length]=monsters[key];
	for (var key in traps)
		if (cardRequired(traps[key])) {
			this.dungeonDeck[this.dungeonDeck.length]=traps[key];
			this.extraDungeonCards++;
		}
	for (var key in guardians)
		if (cardRequired(guardians[key])) {
			this.dungeonDeck[this.dungeonDeck.length]=guardians[key];
			this.extraDungeonCards++;
		}
	this.heroes=new Array();
	for (var key in heroes)
		if (cardRequired(heroes[key]))
			this.heroes[this.heroes.length]=heroes[key];
	this.village=new Array();
	for (var key in village)
		if (cardRequired(village[key]))
			this.village[this.village.length]=village[key];
	this.dungeonDeckSize=function() {
		log("Dungeon deck size: "+(this.extraDungeonCards*1+numberOfMonsters*1));
		return this.extraDungeonCards*1+numberOfMonsters*1;
	}
	this.toString=function(){
		return "Dungeon:"+this.dungeonDeck+"\r\nHeroes:"+this.heroes+"\r\nVillage:"+this.village+"\r\n\r\n";
	}
}

function cardRequired(which) {
	var id=getId(which);
	return $("#"+id).val()=="Yes"
}

function GameRequirements() {
	this.reqs=new Array();
	this.add=function(req) {
		if (document.getElementById("useConditions").checked) {
			var matched=false;
			for (var i=0; i<this.reqs.length; i++) {
				if (this.reqs[i].name==req.name) {
					matched=true;
					this.reqs[i].qty=Math.max(this.reqs[i].qty, req.qty);
				}
			}
			if (!matched)
				this.reqs[this.reqs.length]=clone(req);
		}
	}
	this.count=function() {
		var x=0;
		for (var i=0; i<this.reqs.length; i++)
			x+=this.reqs[i].qty;
		return x;
	}
	this.match=function(card) {
		var toReturn=false;
		for (var i=0; i<this.reqs.length; i++)
			if (this.reqs[i].qty>0 && this.reqs[i].match(card)) {
				toReturn=true;
				this.reqs[i].qty--;
				log(card+" matched "+this.reqs[i]+"; "+this.count()+" matches remaining");
			}
		return toReturn;
	}
}req_hero_attack=new Condition({
	name: "req_hero_attack",
	type: type.hero,
	match: function(card) {
		return (card.has("attack"))
	}
});

req_hero_cleric=new Condition({
	name: "req_hero_cleric",
	type: type.hero,
	match: function(card) {
		return card.is("Cleric")
	}
});

req_hero_fighter=new Condition({
	name: "req_hero_fighter",
	type: type.hero,
	match: function(card) {
		return card.is("Fighter")
	}
});

req_hero_magic_attack=new Condition({
	name: "req_hero_magic_attack",
	type: type.hero,
	match: function(card) {
		return (card.has("magicAttack"))
	}
});

req_hero_strength=new Condition({
	name: "req_hero_strength",
	type: type.hero,
	match: function(card) {
		return (card.has("strength") > heroStrengthThreshold)
	}
});

req_hero_thief=new Condition({
	name: "req_hero_thief",
	type: type.hero,
	match: function(card) {
		return card.is("Thief")
	}
});

req_hero_wizard=new Condition({
	name: "req_hero_wizard",
	type: type.hero,
	match: function(card) {
		return card.is("Wizard")
	}
});

req_village_attack=new Condition({
	name: "req_village_attack",
	type: type.village,
	match: function(card) {
		return (card.has("attack"))
	}
});

req_village_edged_weapon=new Condition({
	name: "req_village_edged_weapon",
	type: type.village,
	match: function(card) {
		return (card.is("Weapon") && card.is("Edged"))
	}
});

req_village_food=new Condition({
	name: "req_village_food",
	type: type.village,
	match: function(card) {
		return card.is("Food")
	}
});

req_village_item=new Condition({
	name: "req_village_item",
	type: type.village,
	match: function(card) {
		return card.is("Item")
	}
});

req_village_light=new Condition({
	name: "req_village_light",
	type: type.village,
	match: function(card) {
		return (card.has("light"))
	}
});

req_village_light_item=new Condition({
	name: "req_village_light_item",
	type: type.village,
	match: function(card) {
		return ((card.has("light")) && card.is("Item"))
	}
});

req_village_magic_attack=new Condition({
	name: "req_village_magic_attack",
	type: type.village,
	match: function(card) {
		return (card.has("magicAttack"))
	}
});

req_village_nonedged_weapon=new Condition({
	name: "req_village_nonedged_weapon",
	type: type.village,
	match: function(card) {
		return (card.is("Weapon") && !card.is("Edged"))
	}
});

req_village_spell=new Condition({
	name: "req_village_spell",
	type: type.village,
	match: function(card) {
		return card.is("Spell")
	}
});

req_village_spell_magic_attack=new Condition({
	name: "req_village_spell_magic_attack",
	type: type.village,
	match: function(card) {
		return ((card.has("magicAttack")) && card.is("Spell"))
	}
});

req_village_strength=new Condition({
	name: "req_village_strength",
	type: type.village,
	match: function(card) {
		return (card.has("strength"))
	}
});

req_village_weapon=new Condition({
	name: "req_village_weapon",
	type: type.village,
	match: function(card) {
		return card.is("Weapon")
	}
});monsters=new Array();
monsters[monsters.length]=new Card({
	name: "Abyssal",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_wizard), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Doomknight * Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_fighter), 
		new Requirement(req_village_light), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Dragon",
	set: set.base,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Nature",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Elemental * Pain",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Enchanted",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
monsters[monsters.length]=new Card({
	name: "Golem",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength)
	]
});
monsters[monsters.length]=new Card({
	name: "Horde",
	set: set.wrath,
	requirements: [
	]
});
monsters[monsters.length]=new Card({
	name: "Humanoid",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Ooze",
	set: set.base,
	requirements: [
		new Requirement(req_village_edged_weapon), 
		new Requirement(req_village_food), 
		new Requirement(req_village_nonedged_weapon), 
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Doom",
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
monsters[monsters.length]=new Card({
	name: "Undead * Spirit",
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength), 
		new Requirement(req_village_weapon)
	]
});

traps=new Array();
traps[traps.length]=new Card({
	name: "Trap * Death",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief)
	]
});
traps[traps.length]=new Card({
	name: "Trap * Dire",
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief),
		new Requirement(req_hero_cleric)
	]
});

guardians=new Array();
guardians[guardians.length]=new Card({
	name: "Dark Champion",
	set: set.wrath,
	requirements: [
	]
});
guardians[guardians.length]=new Card({
	name: "Death Sentinel",
	set: set.promo,
	requirements: [
	]
});
heroes=new Array();
heroes[heroes.length]=new Card({
	name: "Amazon",
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Blind",
	set: set.wrath,
	types: "Fighter Cleric",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_light_item, 2)
	]
});
heroes[heroes.length]=new Card({
	name: "Chalice",
	set: set.base,
	types: "Fighter Cleric",
	strength: 5,
	attack: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Clan",
	set: set.promo,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Diin",
	set: set.wrath,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Divine",
	set: set.wrath,
	types: "Cleric",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Dwarf",
	set: set.base,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
		new Requirement(req_village_edged_weapon), 
		new Requirement(req_village_nonedged_weapon)
	]
});
heroes[heroes.length]=new Card({
	name: "Elf",
	set: set.base,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	light: true,
	removesMonstersFromHall: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Feayn",
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Gangland",
	set: set.wrath,
	types: "Thief",
	strength: 4,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Gohlen",
	set: set.wrath,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Lorigg",
	set: set.base,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Outlands",
	set: set.base,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
heroes[heroes.length]=new Card({
	name: "Redblade",
	set: set.base,
	types: "Fighter Thief",
	strength: 5,
	attack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Regian",
	set: set.base,
	types: "Cleric",
	strength: 4,
	magicAttack: true,
	requirements: [
	]
});
heroes[heroes.length]=new Card({
	name: "Runespawn",
	set: set.wrath,
	types: "Thief Wizard",
	strength: 5,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
heroes[heroes.length]=new Card({
	name: "Selurin",
	set: set.base,
	types: "Wizard",
	strength: 2,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell_magic_attack),
		new Requirement(req_village_item)
	]
});
heroes[heroes.length]=new Card({
	name: "Thyrian",
	set: set.base,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
heroes[heroes.length]=new Card({
	name: "Toryn",
	set: set.wrath,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon, 2)
	]
});village=new Array();
village[village.length]=new Card({
	name: "Ambrosia",
	set: set.wrath,
	types: "Item Food Magic",
	attack: true,
	strength: true
});
village[village.length]=new Card({
	name: "Amulet of Power",
	set: set.wrath,
	types: "Item Light Magic",
	light: true,
	strength: true
});
village[village.length]=new Card({
	name: "Arcane Energies",
	set: set.base,
	types: "Spell",
	magicAttack: true
});
village[village.length]=new Card({
	name: "Banish",
	set: set.base,
	types: "Spell",
	removesMonstersFromHall: true
});
village[village.length]=new Card({
	name: "Barkeep",
	set: set.base,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Battle Fury",
	set: set.base,
	types: "Spell",
	attack: true
});
village[village.length]=new Card({
	name: "Blacksmith",
	set: set.wrath,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Claymore",
	set: set.wrath,
	types: "Weapon Edged",
	attack: true
});
village[village.length]=new Card({
	name: "Creeping Death",
	set: set.wrath,
	types: "Spell",
});
village[village.length]=new Card({
	name: "Cursed Mace",
	set: set.wrath,
	types: "Weapon Blunt",
	attack: true
});
village[village.length]=new Card({
	name: "Feast",
	set: set.base,
	types: "Item Food",
	attack: true,
	strength: true
});
village[village.length]=new Card({
	name: "Fireball",
	set: set.base,
	types: "Spell",
	light: true,
	magicAttack: true
});
village[village.length]=new Card({
	name: "Flaming Sword",
	set: set.base,
	types: "Weapon Edged",
	light: true,
	magicAttack: true
});
village[village.length]=new Card({
	name: "Foresight Elixir",
	set: set.wrath,
	types: "Spell"
});
village[village.length]=new Card({
	name: "Goodberries",
	set: set.base,
	types: "Item Food Magic",
	magicAttack: true,
	strength: true
});
village[village.length]=new Card({
	name: "Hatchet",
	set: set.base,
	types: "Weapon Edged",
	attack: true
});
village[village.length]=new Card({
	name: "Illusory Blade",
	set: set.wrath,
	types: "Spell"
});
village[village.length]=new Card({
	name: "Lantern",
	set: set.base,
	types: "Item Light",
	light: true
});
village[village.length]=new Card({
	name: "Lightstone Gem",
	set: set.base,
	types: "Item Light Magic",
	light: true
});
village[village.length]=new Card({
	name: "Magi Staff",
	set: set.wrath,
	types: "Weapon Blunt Magic",
	magicAttack: true,
	removesMonstersFromHall: true
});
village[village.length]=new Card({
	name: "Magic Missile",
	set: set.wrath,
	types: "Spell",
	magicAttack: true
});
village[village.length]=new Card({
	name: "Magical Aura",
	set: set.base,
	types: "Spell",
	magicAttack: true
});
village[village.length]=new Card({
	name: "Pawnbroker",
	set: set.base,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Polearm",
	set: set.base,
	types: "Weapon Edged",
	attack: true
});
village[village.length]=new Card({
	name: "Sage",
	set: set.wrath,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Short Bow",
	set: set.wrath,
	types: "Weapon Bow",
	attack: true
});
village[village.length]=new Card({
	name: "Short Sword",
	set: set.base,
	types: "Weapon Edged",
	attack: true
});
village[village.length]=new Card({
	name: "Spear",
	set: set.base,
	types: "Weapon Edged",
	attack: true
});
village[village.length]=new Card({
	name: "Tavern Brawl",
	set: set.wrath,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Tax Collector",
	set: set.wrath,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Town Guard",
	set: set.base,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Trainer",
	set: set.base,
	types: "Villager"
});
village[village.length]=new Card({
	name: "Warhammer",
	set: set.base,
	types: "Weapon Blunt"
});

allCards=new Array();
for (var i=0; i<monsters.length; i++)
	allCards[allCards.length]=monsters[i];
for (var i=0; i<heroes.length; i++)
	allCards[allCards.length]=heroes[i];
for (var i=0; i<village.length; i++)
	allCards[allCards.length]=village[i];

printList("filterSetList", "Set", set);
printList("filterCardList", "Monsters", monsters);
printList("filterCardList", "Guardians", guardians);
printList("filterCardList", "Traps", traps);
printList("filterCardList", "Heroes", heroes);
printList("filterCardList", "Village", village);

function getGameSet() {
	document.getElementById("log").value="";
	getOptions();
	gameSet=new GameSet();
	buildDecks();
	heroRequirements=new GameRequirements();
	villageRequirements=new GameRequirements();
	
	//Pick monsters
	for (var i=0; gameSet.dungeonDeck.length<gameSet.dungeonDeckSize()&&i<monsterDeck.length; i++) {
		monster=monsters[monsterDeck[i]];
		gameSet.dungeonDeck[gameSet.dungeonDeck.length]=monster;
		for (var j=0; j<monster.requirements.length; j++) {
			req=monster.requirements[j];
			if (req.type==type.hero)
				heroRequirements.add(req);
			else if (req.type==type.village)
				villageRequirements.add(req);
		}
	}
	
	gameSet.dungeonDeck.sort();
	
	//Pick guardian
	if (Math.random()<guardianChance) {
		if (guardians[guardianDeck[0]]) {//Make sure we actually have a guardian
			guardian=guardians[guardianDeck[0]];
			gameSet.dungeonDeck[gameSet.dungeonDeck.length]=guardian;
			for (var j=0; j<guardian.requirements.length; j++) {
				req=guardian.requirements[j];
				if (req.type==type.hero)
					heroRequirements.add(req);
				else if (req.type==type.village)
					villageRequirements.add(req);
			}
		} else log("No guardians available.");
	} else log("Skipping guardians.");

	//Pick trap
	if (Math.random()<trapChance) {
		if (traps[trapDeck[0]]) {//Make sure we actually have a trap
			trap=traps[trapDeck[0]];
			gameSet.dungeonDeck[gameSet.dungeonDeck.length]=trap;
			for (var j=0; j<trap.requirements.length; j++) {
				req=trap.requirements[j];
				if (req.type==type.hero)
					heroRequirements.add(req);
				else if (req.type==type.village)
					villageRequirements.add(req);
			}
		} else log("No traps available.");
	} else log("Skipping traps.");
	
	//Pick heroes
	for (var i=0; gameSet.heroes.length<numberOfHeroes&&i<heroDeck.length; i++) {
		hero=heroes[heroDeck[i]];
		keep=(i+heroRequirements.count()<numberOfHeroes); //False if not enough "free" slots left
		keep=(heroRequirements.match(hero)||keep); //True if the card matches a requirement
		keep=((heroDeck.length-i <= numberOfHeroes-gameSet.heroes.length)||keep); //True if we're running out of cards
		if (keep) {
			gameSet.heroes[gameSet.heroes.length]=hero;
			for (var j=0; j<hero.requirements.length; j++) {
				req=hero.requirements[j];
				if (req.type==type.village)
					villageRequirements.add(req);
			}
		} else
			log(hero+" discarded due to lack of space");
	}

	gameSet.heroes.sort();
	
	//Pick village cards
	for (var i=0; gameSet.village.length<numberOfVillageCards&&i<villageDeck.length; i++) {
		vcard=village[villageDeck[i]];
		keep=(gameSet.village.length+villageRequirements.count()<numberOfVillageCards); //False if not enough "free" slots left
		keep=(villageRequirements.match(vcard)||keep); //True if the card matches a requirement
		keep=((villageDeck.length-i <= numberOfVillageCards-gameSet.village.length)||keep); //True if we're running out of cards
		if (keep)
			gameSet.village[gameSet.village.length]=vcard;
		else
			log(vcard+" discarded due to lack of space");
	}

	gameSet.village.sort();

	//Troubleshooting
	if (heroRequirements.count()>0) {
		log("Hero requirements:");
		indent++;
		for (var i=0; i<heroRequirements.reqs.length; i++) {
			req=heroRequirements.reqs[i];
			log(req+" required "+req.qty+" more");
		}
		indent--;
	}
	if (villageRequirements.count()>0) {
		log("Village requirements:");
		indent++;
		for (var i=0; i<villageRequirements.reqs.length; i++) {
			req=villageRequirements.reqs[i];
			log(req+" required "+req.qty+" more");
		}
		indent--
	}/**/


	return gameSet;
}
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Amazon,
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Belzur,
	set: set.dragonspire,
	types: "Cleric",
	strength: 4,
	destroysDisease: true,
	magicAttack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Blind,
	set: set.wrath,
	types: "Fighter Cleric",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_light_item, 2)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Cabal,
	set: set.dragonspire,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Chalice,
	set: set.base,
	types: "Fighter Cleric",
	strength: 5,
	attack: true,
	destroysDisease: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Chulian,
	set: set.dragonspire,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Clan,
	set: set.promo,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Deep,
	set: set.doom,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Diin,
	set: set.wrath,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Drunari,
	set: set.doom,
	types: "Thief",
	strength: 3,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Divine,
	set: set.wrath,
	types: "Cleric",
	strength: 4,
	attack: true,
	destroysDisease: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Dwarf,
	set: set.base,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
		new Requirement(req_village_edged_weapon),
		new Requirement(req_village_nonedged_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Elf,
	set: set.base,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	light: true,
	removesMonstersFromHall: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Evoker,
	set: set.dragonspire,
	types: "Archer Wizard",
	strength: 4,
	attack: true,
	light: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Feayn,
	set: set.base,
	types: "Fighter Archer",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Flame,
	set: set.dragonspire,
	types: "Fighter Wizard",
	strength: 5,
	attack: true,
	light: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Gangland,
	set: set.wrath,
	types: "Thief",
	strength: 4,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Gohlen,
	set: set.wrath,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Gorinth,
	set: set.dragonspire,
	types: "Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Half_Orc,
	set: set.dragonspire,
	types: "Fighter Thief",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_food),
		new Requirement(req_village_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Harruli,
	set: set.promo,
	types: "Fighter Wizard",
	strength: 5,
	attack: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Krell,
	set: set.thorn,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_mercenary)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Lorigg,
	set: set.base,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Lurker,
	set: set.thorn,
	types: "Thief",
	strength: 4,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_light_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Magehunter,
	set: set.thorn,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
		new Requirement(req_village_magic_attack),
		new Requirement(req_village_mercenary)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Nightblade,
	set: set.thorn,
	types: "Fighter Thief",
	strength: 4,
	attack: true,
	requirements: [
		new Requirement(req_village_light_item),
		new Requirement(req_village_weapon_edged_weighs_lt_3)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Outlands,
	set: set.base,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Phalanx,
	set: set.dragonspire,
	types: "Fighter",
	strength: 5,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Redblade,
	set: set.base,
	types: "Fighter Thief",
	strength: 5,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Regian,
	set: set.base,
	types: "Cleric",
	strength: 4,
	destroysDisease: true,
	magicAttack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Runespawn,
	set: set.wrath,
	types: "Thief Wizard",
	strength: 5,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Selurin,
	set: set.base,
	types: "Wizard",
	strength: 2,
	magicAttack: true,
	requirements: [
		new Requirement(req_village_spell_magic_attack),
		new Requirement(req_village_item)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Sidhe,
	set: set.doom,
	types: "Cleric",
	strength: 3,
	destroysDisease: true,
	magicAttack: true,
	requirements: [
		new Requirement(req_disease_special)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Slynn,
	set: set.doom,
	types: "Fighter Archer",
	strength: 5,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Stoneguard,
	set: set.dragonspire,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon),
		new Requirement(req_village_mercenary)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Tempest,
	set: set.doom,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Terakian,
	set: set.dragonspire,
	types: "Fighter Cleric",
	strength: 3,
	attack: true,
	destroyDisease: true,
	requirements: [
		new Requirement(req_village_villager)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Thornwood,
	set: set.thorn,
	types: "Archer",
	strength: 4,
	attack: true,
	requirements: [
		
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Tholis,
	set: set.doom,
	types: "Thief Wizard",
	strength: 3,
	magicAttack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Thyrian,
	set: set.base,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
		new Requirement(req_village_food)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Toryn,
	set: set.wrath,
	types: "Fighter",
	strength: 7,
	attack: true,
	requirements: [
		new Requirement(req_village_weapon, 2)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Verdan,
	set: set.doom,
	types: "Fighter Thief",
	strength: 5,
	attack: true,
	light: true,
	requirements: [
		new Requirement(req_village_spell)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Veris,
	set: set.thorn,
	types: "Wizard",
	strength: 4,
	magicAttack: true,
	light: true,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Veteran,
	set: set.dragonspire,
	types: "Fighter",
	strength: 6,
	attack: true,
	requirements: [
	]
});
cards[local.Hero][cards[local.Hero].length]=new Card({
	name: local.Woodfolk,
	set: set.thorn,
	types: "Fighter Cleric",
	strength: 4,
	attack: true,
	destroysDisease: true,
	requirements: [
		
	]
});

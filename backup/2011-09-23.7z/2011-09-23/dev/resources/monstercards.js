cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Abyssal,
	set: set.base,
	requirements: [
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_wizard), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Abyssal_Malformed,
	set: set.thorn,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_fighter),
		new Requirement(req_village_food),
		new Requirement(req_village_light_item)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Abyssal_Thunderspawn,
	set: set.doom,
	requirements: [
		new Requirement(req_hero_archer), 
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_wizard)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Bandit_Humanoid,
	set: set.dragonspire,
	requirements: [
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Centaur,
	set: set.thorn,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_fighter)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Cultist_Humanoid,
	set: set.doom,
	requirements: [
		new Requirement(req_village_item),
		new Requirement(req_village_light),
		new Requirement(req_village_spell),
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Dark_Enchanted,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_archer),
		new Requirement(req_village_edged_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Doomknight_Humanoid,
	set: set.base,
	requirements: [
		new Requirement(req_hero_fighter), 
		new Requirement(req_village_light), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Dragon,
	set: set.base,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Dragon_Humanoid,
	set: set.promo,
	requirements: [
		new Requirement(req_hero_archer), 
		new Requirement(req_hero_cleric), 
		new Requirement(req_hero_fighter), 
		new Requirement(req_hero_thief), 
		new Requirement(req_hero_wizard)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Elemental_Fire,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_item),
		new Requirement(req_village_spell)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Elemental_Nature,
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Elemental_Pain,
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Enchanted,
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_magic_attack)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Evil_Druid_Humanoid,
	set: set.doom,
	requirements: [
		new Requirement(req_hero_cleric),
		new Requirement(req_disease_special),
		new Requirement(req_hero_destroys_disease)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Giant,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_strength),
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Golem,
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Horde,
	set: set.wrath,
	requirements: [
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Humanoid,
	set: set.base,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Hydra_Dragon,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Ooze,
	set: set.base,
	requirements: [
		new Requirement(req_village_edged_weapon), 
		new Requirement(req_village_food), 
		new Requirement(req_village_nonedged_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Orc_Humanoid,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_village_mercenary),
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Raider_Humanoid,
	set: set.thorn,
	requirements: [
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Siege,
	set: set.thorn,
	requirements: [
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.The_Swarm,
	set: set.doom,
	requirements: [
		new Requirement(req_disease_special)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Undead_Doom,
	set: set.base,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_village_spell), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Undead_Lich,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_attack),
		new Requirement(req_hero_cleric),
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_magic_attack),
		new Requirement(req_hero_wizard),
		new Requirement(req_village_attack),
		new Requirement(req_village_magic_attack),
		new Requirement(req_village_spell)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Undead_Plague,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_destroys_disease)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Undead_Spirit,
	set: set.base,
	requirements: [
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_hero_strength), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_strength), 
		new Requirement(req_village_weapon)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Undead_Stormwraith,
	set: set.doom,
	requirements: [
		new Requirement(req_hero_attack), 
		new Requirement(req_hero_magic_attack), 
		new Requirement(req_village_attack), 
		new Requirement(req_village_magic_attack), 
		new Requirement(req_village_spell)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Verminfolk_Animal,
	set: set.thorn,
	requirements: [
		new Requirement(req_hero_destroys_disease),
		new Requirement(req_hero_fighter)
	]
});
cards[local.Monster][cards[local.Monster].length]=new Card({
	name: local.Werewolf,
	set: set.promo,
	requirements: [
		new Requirement(req_village_villager)
	]
});

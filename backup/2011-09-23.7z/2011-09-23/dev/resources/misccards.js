cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Agony,
	set: set.wrath
});
cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Blight,
	set: set.thorn
});
cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Avarice,
	set: set.doom
});
cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Mystery,
	set: set.base
});
cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Scorn,
	set: set.dragonspire
});
cards[local.Thunderstone][cards[local.Thunderstone].length]=new Card({
	name: local.Stone_of_Terror,
	set: set.dragonspire
});

cards[local.Trap][cards[local.Trap].length]=new Card({
	name: local.Trap_Death,
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief)
	]
});
cards[local.Trap][cards[local.Trap].length]=new Card({
	name: local.Trap_Dire,
	set: set.wrath,
	requirements: [
		new Requirement(req_hero_thief),
		new Requirement(req_hero_cleric)
	]
});
cards[local.Trap][cards[local.Trap].length]=new Card({
	name: local.Trap_Draconic,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_thief),
	]
});

cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Dark_Champion,
	set: set.wrath,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Death_Sentinel,
	set: set.promo,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Guardian_of_Night,
	set: set.dragonspire,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Guardian_of_Revenge,
	set: set.promo,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Guardian_of_Strength,
	set: set.promo,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Guardian_of_Torment,
	set: set.dragonspire,
	requirements: [
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Guardian_of_Virulence,
	set: set.thorn,
	requirements: [
		new Requirement(req_hero_destroys_disease)
	]
});
cards[local.Guardian][cards[local.Guardian].length]=new Card({
	name: local.Unholy_Guardian,
	set: set.doom,
	requirements: [
	]
});

cards[local.Treasure][cards[local.Treasure].length]=new Card({
	name: local.Amulet_Treasure,
	set: set.doom,
	requirements: [
	]
});
cards[local.Treasure][cards[local.Treasure].length]=new Card({
	name: local.Figurine_Treasure,
	set: set.dragonspire,
	requirements: [
	]
});
cards[local.Treasure][cards[local.Treasure].length]=new Card({
	name: local.Ulbrick_s_Treasure,
	set: set.doom,
	requirements: [
	]
});

cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Barrowsdale,
	set: set.dragonspire
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Doomgate,
	set: set.dragonspire,
	execute: function() {
		cardTypes[MONSTER].count++;
	}
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Dragonspire,
	set: set.dragonspire,
	execute: function() {
		cardTypes[THUNDERSTONE].count++;
		cardTypes[MONSTER].count++;
	}
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Dreadwatch,
	set: set.dragonspire,
	requirements: [
		new Requirement(req_hero_destroys_disease)
	]
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Feayn_Swamp,
	set: set.dragonspire
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Grimhold,
	set: set.dragonspire
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Regian_Cove,
	set: set.dragonspire
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Stormhold,
	set: set.promo
});
cards[local.Setting][cards[local.Setting].length]=new Card({
	name: local.Thornwood_Forest,
	set: set.promo
});

